%读取step20 step21的结果，并且计算train data 和 test data的卡方自由度结果


clear;clc; addpath('scripts\')


%%
all_BMDDM=dir('cross_validation_BMDDM\*.mat');
[~,index] = sortrows({all_BMDDM.name}.'); all_BMDDM = all_BMDDM(index); clear index

bins=5;

for sub=1:70
    fprintf('.');
    load(['cross_validation_BMDDM\',all_BMDDM(sub).name]);
    params=record(1,10:18);
    train_data_chi2_FIPS=record(1,19); %训练数据的卡方值
    test_data_chi2_FIPS=0;
    
    for d=1:length(subdata)
        alertness_value=subdata(d).alertness_info(2);
        
        drift_rate_m = params(1)*  (alertness_value^params(2)) + params(3) ;
        drift_rate_sd=params(5)* (params(4)^alertness_value) ;
        ndt=params(7)* (params(6)^alertness_value) ;
        ndt_range=params(9)* (params(8)^alertness_value) ;
        
        RTs=subdata(d).test_data;
        RTs=sort(RTs);
        inx=find(diff(RTs)==0);
        RTs(inx)=RTs(inx)-0.000001; %防止相同的反应时变成边界，导致bin划分不准
        
        inx=linspace(0.0001,bins,length(RTs));
        inx=ceil(inx);
        bins_end=[];
        for i=1:bins
            thisinx=find(inx==i);
            bins_end(i)=RTs(thisinx(end));
        end
        
        bins_end(end)=Inf;
        bins_end=[0,bins_end];
        bins_info=[bins_end(1:end-1);bins_end(2:end)];
        data=bins_info;
        
        % 提前将每一个bin里的观测值记录入data
        for i=1:bins
            inx1=RTs>data(1,i);
            inx2=RTs<=data(2,i);
            O(i)=sum(inx1.*inx2);
        end
        
        data(3,:)=O;
        
        [chi_square,~]=chi_square_fit_x(data, [drift_rate_m,drift_rate_sd,ndt,ndt_range] ,3000);
        test_data_chi2_FIPS=test_data_chi2_FIPS+chi_square;
    end
    save(['cross_validation_BMDDM\',all_BMDDM(sub).name],'subdata','record','train_data_chi2_FIPS','test_data_chi2_FIPS');
    
    BMDDM_r(sub).test_data_chi2_FIPS=test_data_chi2_FIPS;
    BMDDM_r(sub).train_data_chi2_FIPS=train_data_chi2_FIPS;
    BMDDM_r(sub).chi2df_test=test_data_chi2_FIPS/(d*bins-1);
    BMDDM_r(sub).chi2df_train=train_data_chi2_FIPS/(d*bins-1);
    
end

name70={all_BMDDM.name};
%%

all_IDDM=dir('cross_validation_IDDM\*.mat');
bins=5;
freedom_degree=bins-1;

%对照BMDDM，提取即在BMDDM里存在，也在IDDM里存在的70个被试。
for sub=1:131
    thisname=all_IDDM(sub).name;
    all_IDDM(sub).name2=thisname(strfind(thisname,' ')+1:end) ;
    if ismember( all_IDDM(sub).name2 , name70)
        all_IDDM(sub).res=1;
    else
        all_IDDM(sub).res=0;
    end
end
all_IDDM=all_IDDM(find([all_IDDM.res]));
[~,index] = sortrows({all_IDDM.name2}.'); all_IDDM = all_IDDM(index); clear index;

%
IDDM_r=[];
for sub=1:70
    
    load(['cross_validation_IDDM\',all_IDDM(sub).name]);

    n=0;
    for d=1:length(subdata)
        
        record=subdata(d).record;
        
        if ~isempty(record)
            
            params=record(1,5:8);
            RTs=subdata(d).test_data;
            RTs=sort(RTs);
            inx=find(diff(RTs)==0);
            RTs(inx)=RTs(inx)-0.000001; %防止相同的反应时变成边界，导致bin划分不准
            
            inx=linspace(0.0001,bins,length(RTs));
            inx=ceil(inx);
            bins_end=[];
            for i=1:bins
                thisinx=find(inx==i);
                bins_end(i)=RTs(thisinx(end));
            end
            
            bins_end(end)=Inf;
            bins_end=[0,bins_end];
            bins_info=[bins_end(1:end-1);bins_end(2:end)];
            data=bins_info;
            
            % 提前将每一个bin里的观测值记录入data
            for i=1:bins
                inx1=RTs>data(1,i);
                inx2=RTs<=data(2,i);
                O(i)=sum(inx1.*inx2);
            end
            
            data(3,:)=O;
            [chi_square,Tall]=chi_square_fit_x(data,params,3000);
            subdata(d).chi_square_of_train=record(1,9);
            subdata(d).chi_square_of_test=chi_square;
             
            n=n+1;
        end
    end
    try
        
        IDDM_r(sub).test_data_chi2=sum([subdata.chi_square_of_test]);
        IDDM_r(sub).train_data_chi2=sum([subdata.chi_square_of_train]);
        IDDM_r(sub).chi2df_test= sum([subdata.chi_square_of_test])/ (freedom_degree*n-1 ); 
        IDDM_r(sub).chi2df_train= sum([subdata.chi_square_of_train])/ (freedom_degree*n-1 ); 
    catch
    end
  
    fprintf('.');
end

disp('IDDM done');


%%

color11=[137 217 215]/255; %model 1  exp model
color21=[243 200 162]/255; %model 2  power model
color31=[114 185 252]/255; %model 3  mixture model
color41=[200 120 249]/255;  %model4 sigmoid model
color51=[240 130 144]/255;  %I-DDM color

color12=[52 126 135]/255;
color22=[221 136 99]/255;
color32=[21 117 240]/255;
color42=[140 30 243]/255;
color52=[226 49 102]/255;

figure;
IDDM_chi2df_test=log10([IDDM_r.chi2df_test]);
IDDM_chi2df_train=log10([IDDM_r.chi2df_train]);
draw_violin(IDDM_chi2df_train,1,color51,color52,[0.2,0.2,0.2],0.25,0.08);
draw_violin(IDDM_chi2df_test,2,color51,color52,[0.2,0.2,0.2],0.3,0.08);

BMDDM_chi2df_train=log10([BMDDM_r.chi2df_train]);
BMDDM_chi2df_test=log10([BMDDM_r.chi2df_test]);
draw_violin(BMDDM_chi2df_train,3,  color31,color32 ,[0.2,0.2,0.2],0.25,0.08);
draw_violin(BMDDM_chi2df_test,4, color31,color32 ,[0.2,0.2,0.2],0.25,0.08);

ylim([-2,3]);
YTick=-2:3;
for i=1:length(YTick)
    YTickLabel{i} = [ '10^',num2str(YTick(i)) ] ;
end
set(gca,'YTick',-2:3,'YTickLabel',YTickLabel);

set(gca,'XTick',[1,2,3,4],'XTicklabel',{'train','test','train','test'});
ylabel('Normalized Chi-Square')


% saveas(gcf,'chi2df trian test','svg');

% 计算cohen'd
% sp=sqrt(((length(IDDM_chi2df_test)-1)*std(IDDM_chi2df_test)^2+(length(BMDDM_chi2df_test)-1)*std(BMDDM_chi2df_test)^2)/(length(IDDM_chi2df_test)+length(BMDDM_chi2df_test)-2));
% (mean(IDDM_chi2df_test)-mean(BMDDM_chi2df_test))/sp

%在交叉验证的测试集数据里，mixture model的卡方自由度值结果比IDDM好13.5%
mean((log([BMDDM_r.chi2df_test])-log([IDDM_r.chi2df_test]))./log([IDDM_r.chi2df_test]))
mean(([BMDDM_r.chi2df_test]-[IDDM_r.chi2df_test])./[IDDM_r.chi2df_test])



