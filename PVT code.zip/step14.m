% 对fit with FIPS 已经拟合完毕的结果进行整理
% 同时根据被试完成PVT任务时的alertness信息，计算被试该次任务所对应的DDM参数
% 以及计算每一个被试的拟合结果的chi2df 卡方自由度比
% 最后计算每一个被试的联合建模的AIC 和BIC值，
% 注意nll计算中的sample_num和bin_width是固定为100000和0.05的，不可更改

clear;clc;

thispath='第二十次fit'; %指定要整理哪一次拟合结果，  会直接从fit_with_FIPS_result文件夹内寻找相应结果，并且整理后的结果也保存在同一文件夹下

fit_result=dir(['fit_with_FIPS_result\',thispath,'\*.mat']);
load('process_data\step12_alldata_forFIPS_fit');
step14_alldata=step12_alldata_forFIPS_fit;

bins=5;  %联合建模拟合时所用的bin的数量
%%

for sub=1:length(fit_result)
    thisname=fit_result(sub).name;
    load(['fit_with_FIPS_result\',thispath,'\',thisname]);
    
    thisname=thisname(1:5);
    inx=strcmp({step14_alldata.subdir_name},thisname);
    
    params_num=(size(record,2)-2)/2;
    params=record(1,params_num+1:params_num*2);
    step14_alldata(inx).fit_with_FIPS_result=params;
    chi2_FIPS=record(1,params_num*2+1);
    step14_alldata(inx).chi2_FIPS=chi2_FIPS;
    
    subdata=step14_alldata(inx).subdata;
    
    n=0;
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT2) || isempty(subdata(d).alertness_info)
            continue;
        end
        n=n+1;
        
        alertness_value=subdata(d).alertness_info(2);

        %%         这里需要修改以下代码，以符合fit阶段的DDM参数计算方法!!!!!!!!!!!!!!!!!!!!!!!!注意！！！！！！！！！注意！！！
        
        %第5次fit、第6次fit、第12次，第13次，所有DDM使用2参数，关系式为  P = B * A^alertness
%         drift_rate_m=params(2) * (  params(1)^alertness_value) ;
%         drift_rate_sd=params(4)* (params(3)^alertness_value) ;
%         ndt=params(6)* (params(5)^alertness_value) ;
%         ndt_range=params(8)* (params(7)^alertness_value) ;
        
        %         %第8次fit  第10次fit  第15次fit  所有DDM参数都使用3参数      关系式为  P = A * alertness^B +C
%         drift_rate_m = params(1)*  (alertness_value^params(2)) + params(3) ;
%         drift_rate_sd = params(4)*  (alertness_value^params(5)) + params(6) ;
%         ndt = params(7)*  (alertness_value^params(8)) + params(9) ;
%         ndt_range= params(10)*  (alertness_value^params(11)) + params(12) ;
        %
        
        %第9次fit适配，第14次fit， 也就是drift rate使用3参数同fit8， 其他几个都使用2参数同fit5
%                 drift_rate_m = params(1)*  (alertness_value^params(2)) + params(3) ;
%                 drift_rate_sd=params(5)* (params(4)^alertness_value) ;
%                 ndt=params(7)* (params(6)^alertness_value) ;
%                 ndt_range=params(9)* (params(8)^alertness_value) ;
        
        %         %         %         第11次fit适配  第20次fit适配，4个DDM参数都使用sigmod
                drift_rate_m = params(1) ./ ( 1 + exp(( -alertness_value + params(2) ) * params(3) )) + params(4);
                drift_rate_sd = params(5) ./ ( 1 + exp(( -alertness_value + params(6) ) * params(7) )) + params(8);
                ndt = params(9) ./ ( 1 + exp(( -alertness_value + params(10) ) * params(11) )) + params(12);
                ndt_range= params(13) ./ ( 1 + exp(( -alertness_value + params(14) ) * params(15) )) + params(16);
        
        %%
        subdata(d).ddm_params_by_FIPS=[drift_rate_m,drift_rate_sd,ndt,ndt_range];
    end
    
    step14_alldata(inx).chi2_df_rate_FIPS=chi2_FIPS/(n*bins-1);
    
    step14_alldata(inx).subdata=subdata;
    
    fprintf('.');
end

%%  对个被试的每一个PVT实验进行一次nll计算
sample_num=100000; %采样数量， 这个值不能随意修改
bin_width=0.05; %单个bin的宽度， 这个值不能随意修改
%上面两个参数不可随意修改， 因为会影响到计算出的nll结果，目前所有模型的nll均使用上述参数进行
%只有保证所有模型和数据都使用同样的sample_num和bin_width，才可以进行模型比较

for sub=1:length(step14_alldata)
    subdata=step14_alldata(sub).subdata;
    for d=1:length(subdata)
        allRT=subdata(d).valid_RT2;
        params=subdata(d).ddm_params_by_FIPS;
        nll=gene_nll(params,sample_num,bin_width,allRT);
        subdata(d).FIPS_nll=nll;
    end
    step14_alldata(sub).subdata=subdata;
    
    n =sum(cellfun(@length,{subdata.valid_RT2}));%所有的试次数量
    
    step14_alldata(sub).FIPS_AIC=sum([subdata.FIPS_nll]) *2 + 2 * params_num ;  
    
    step14_alldata(sub).FIPS_BIC=sum([subdata.FIPS_nll]) *2 +   log(n) * params_num; 
    
    step14_alldata(sub).n=n;
    disp(sub);
end


%%
save(['fit_with_FIPS_result\',thispath,'\step14_alldata'],'step14_alldata');


















