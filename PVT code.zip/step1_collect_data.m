%从原始数据（CE_data以及SH_data）里初步整理CE和SH数据，并且保存为CE_data.mat和SH_data.mat，保存在process_data里
% 但这些数据仍需要进一步筛选，例如去除试次量过少的数据，去除无效试次，这部分操作会在稍后的步骤里进行

clear;clc;

%%
CE=dir('CE_data\CE*');
CE_alldata=[];
for s=1:length(CE)
    subdirdata=dir(['CE_data\',CE(s).name,'\*.csv']);
    
    subdata=[];
    for d=1:length(subdirdata)
        [~,~,raw]=xlsread(['CE_data\',CE(s).name,'\',subdirdata(d).name]);
        
        subdata(d).file_name=subdirdata(d).name;
        subdata(d).STUDY_NAME=raw{2,2};
        subdata(d).STUDY_GROUP=raw{3,2};
        subdata(d).SUBJECT_ID=raw{4,2};
        subdata(d).TRIAL=raw{5,2};
        
        subdata(d).TRIAL_DATE_TIME=raw{6,2};
        subdata(d).HANDEDNESS=raw{7,2};
        
        subdata(d).IOS_DEVICE=raw{8,2};
        subdata(d).IOS_VERSION=raw{9,2};
        subdata(d).LATENCY_OFFSET=raw{10,2};
        
        expdata=raw(13:end,:);
        result=[];
        for trial=1:size(expdata,1)
            result(trial).trial=trial;
            
            if isnumeric(expdata{trial,1})
                result(trial).trial_onset_time=expdata{trial,2}-expdata{trial,1}/1000;
            else
                result(trial).trial_onset_time=[];
            end
            
            result(trial).trial_end_time=expdata{trial,2};
            result(trial).subres=expdata{trial,1};
        end
        
        subdata(d).trialnum=trial;
        subdata(d).result=result;
    end
    CE_alldata(s).subdir_name=CE(s).name;
    CE_alldata(s).subdata=subdata;
    
    disp(s);
end

save('process_data/CE_data','CE_alldata');

%%
SH=dir('SH_data\SH*');
SH_alldata=[];
for s=1:length(SH)
    subdirdata=dir(['SH_data\',SH(s).name,'\*.csv']);
    
    subdata=[];
    for d=1:length(subdirdata)
        [~,~,raw]=xlsread(['SH_data\',SH(s).name,'\',subdirdata(d).name]);
        
        subdata(d).file_name=subdirdata(d).name;
        
        sn=subdirdata(d).name;
        inx1=strfind(sn,'-');
        inx2=strfind(sn,' ');
        inx3=strfind(sn,'.');
        inx4=strfind(sn,'_');
        
        subdata(d).TRIAL_DATE_TIME=[[sn(inx1(2)+1:inx1(3)-1),'-',sn(inx1(3)+1:inx2-1),'-',sn(inx1(1)+1:inx1(2)-1)],' ',[sn(inx2(1)+1:inx4(1)-1),':',sn(inx4(1)+1:inx4(2)-1)]];
        
        if size(raw,1)<=2
            continue;
        end
        
        subdata(d).subid=raw{3,2};
        
        expdata=raw(3:end,:);
        inx=isnan([expdata{:,3}]);
        inx2=find(inx);
        extra_info=[];
        if ~isempty(inx2)
            extra_info =  expdata(inx2(1):end,1:2);
            expdata = expdata(1:inx2(1)-1,:);
        end
        
        result=[];
        for trial=1:size(expdata,1)
            result(trial).trial=trial;
            result(trial).onset_time=expdata{trial,4};
            result(trial).sti_type=expdata{trial,5};
            result(trial).resp_time=expdata{trial,7};
            result(trial).resp_type=expdata{trial,8};
            if isnumeric(expdata{trial,6})
                result(trial).subres=expdata{trial,6}-expdata{trial,3};
            else
                result(trial).subres=[];
            end
        end
        
        subdata(d).trialnum=trial;
        subdata(d).result=result;
        subdata(d).extra_info=extra_info;
        
    end
    
    SH_alldata(s).subdir_name=SH(s).name;
    SH_alldata(s).subdata=subdata;
    
    disp(s);
end

save('process_data/SH_data','SH_alldata');




