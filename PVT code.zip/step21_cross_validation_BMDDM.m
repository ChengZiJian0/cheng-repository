% 采用p9模型
% 在拟合时候，把被试的每一次PVT结果随机分成两份，一份作为训练集进行拟合， 另一份作为测试集用于后续cross测试
% 使用的数据和IDDM拟合的第8次一致
% 这个函数与step13基本一致， 但增加了对于subdata里的 valid_RT2(也就是用于拟合的数据)的拆分功能——随机拆分为两份
% 其中用于train的数据仍然名为valid_RT2，这是为了能够不影响对fit_with_alertness_9这个函数的使用
% 用于test的数据名称为test_data
% 另外这个函数的结果保存里也增加了subdata

function step21_cross_validation_BMDDM(substart,subend)

clc;addpath('scripts');addpath('scripts/bads-master');
load('step12_alldata_forFIPS_fit.mat');
alldata=step12_alldata_forFIPS_fit;


%%               
bounds=[-5 ,    0  ,  0    ,     0     , 1   ,    0    ,  0.1 ,   0  ,  0.1;
                    5 ,    2  , 10    ,  1.5  , 20  ,  1.5  ,    5   , 1.5 ,   5   ];


%%
alldata=alldata(substart:subend);
delete(gcp('nocreate'));
parpool(5);

%%
for sub=1:length(alldata)
    if isempty(alldata(sub).r)  || isempty(alldata(sub).alertness)
        continue;
    end
    
    subdata=alldata(sub).subdata;
    subdata(cellfun(@isempty,{subdata.alertness_info}))=[];
    subdata(cellfun(@isempty,{subdata.params}))=[];
    subdata(cellfun(@isempty,{subdata.valid_RT2}))=[];
    for d=1:length(subdata)
        valid_RT2=subdata(d).valid_RT2;
        inx=round(length(valid_RT2)*0.5);
        valid_RT2=Shuffle(valid_RT2);
        subdata(d).valid_RT2=valid_RT2(1:inx);
        subdata(d).test_data=valid_RT2(inx+1:end);
    end
    fitfun=@(params) fit_with_alertness_9(subdata,params);
    
    record=[];
    tic;
    parfor i=1:5
        range=bounds(2,:)-bounds(1,:);
        params=rand(1,length(range)).*range+bounds(1,:);
        [x1,fval,exitflag] = bads(fitfun,params,bounds(1,:),bounds(2,:),bounds(1,:),bounds(2,:));
        record(i,:)=[params,x1,fval,exitflag];
    end
    toc;
    
    record=sortrows(record,size(record,2)-1);
    
    save(['cross_validation_BMDDM/', alldata(sub).subdir_name],'record','subdata')
end


