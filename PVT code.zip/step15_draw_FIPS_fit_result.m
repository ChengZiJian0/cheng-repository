clear;clc;
addpath('scripts');
thispath='第十八次fit';
p_list=[3 2 2 2]; %!!!!!!!!!!!!!!!!!!!!!!!!!!!!!这个参数需要根据不同的模型进行调整， 例如fit8对每个DDM参数都用ABC进行fit， 而fit9则对第一个参数进行ABCfit，对其他几个参数用ABfit
load(['fit_with_FIPS_result\',thispath,'\step14_alldata.mat']);
[~,index] = sortrows({step14_alldata.subdir_name}.'); step14_alldata = step14_alldata(index); clear index
% step14_alldata([step14_alldata.chi2_df_rate_FIPS]>8)=[];
% length(step14_alldata)

%% 一，绘制所有被试参数的bar图和散点图

allparams=cat(1,step14_alldata.fit_with_FIPS_result); %所有参数
if sum(p_list)~=size(allparams,2)
    error('!!');
end
pname={'DRM','DRS', 'NDT', 'NDT-range'};

hsvlist=linspace(0,0.8,size(allparams,1))';
hsvlist(:,2)=0.6;
hsvlist(:,3)=0.9;
rgblist=hsv2rgb(hsvlist);

figure;

rowsnum=max(p_list); %一共画几行图， 每一列是一个DDM参数
set(gcf,'Color',[1,1,1]);
for p=1:4
    
    thisp= allparams(:,  sum(p_list(1:p-1))+1 : sum(p_list(1:p)));
    
    p1=thisp(:,1);
    p2=thisp(:,2);
    p3=[];
    p4=[];
    if size(thisp,2)==3
        p3=thisp(:,3);
    elseif size(thisp,2)==4
        p3=thisp(:,3);
        p4=thisp(:,4);    
    end
    
    subplot(rowsnum,4,p);
    cla
    hold on
    set(gca,'LineWidth',2,'FontWeight','bold');
    bar(1 , mean(p1),0.8);
    [p1,p1_order]=sort(p1);
    for i=1:length(p1)
        s1=scatter(randn*0.1+1,p1(i));
        s1.CData=rgblist(i,:);
    end
    errorbar(1, mean(p1), std(p1)/sqrt(length(p1))  ,'Linestyle','None','linewidth',2,'Color',[0.3,0.3,0.3]);
    ylabel('A');
    set(gca,'XTick',[]);
    set(gca,'Box','off');
    
    subplot(rowsnum,4,p+4);
    cla
    hold on
    set(gca,'LineWidth',2,'FontWeight','bold');
    bar(1 , mean(p2),0.8);
    p2=p2(p1_order);
    for i=1:length(p2)
        s1=scatter(randn*0.1+1,p2(i));
        s1.CData=rgblist(i,:);
    end
    errorbar(1, mean(p2), std(p2)/sqrt(length(p2))  ,'Linestyle','None','linewidth',2,'Color',[0.3,0.3,0.3]);
    ylabel('B');
    set(gca,'XTick',[])
    set(gca,'Box','off');
    
    if ~isempty(p3)
        subplot(rowsnum,4,p+8);
        cla
        hold on
        set(gca,'LineWidth',2,'FontWeight','bold');
        bar(1 , mean(p3),0.8);
        p3=p3(p1_order);
        for i=1:length(p3)
            s1=scatter(randn*0.1+1,p3(i));
            s1.CData=rgblist(i,:);
        end
        errorbar(1, mean(p3), std(p3)/sqrt(length(p3))  ,'Linestyle','None','linewidth',2,'Color',[0.3,0.3,0.3]);
        ylabel('C');
        set(gca,'XTick',[]);
        set(gca,'Box','off');
    end
    
    if ~isempty(p4)
        subplot(rowsnum,4,p+12);
        cla
        hold on
        set(gca,'LineWidth',2,'FontWeight','bold');
        bar(1 , mean(p4),0.8);
        p4=p4(p1_order);
        for i=1:length(p4)
            s1=scatter(randn*0.1+1,p4(i));
            s1.CData=rgblist(i,:);
        end
        errorbar(1, mean(p4), std(p4)/sqrt(length(p4))  ,'Linestyle','None','linewidth',2,'Color',[0.3,0.3,0.3]);
        ylabel('D');
        set(gca,'XTick',[]);
        set(gca,'Box','off');
    end
    
    xlabel(pname{p});
end
set(gcf,'position',[100,100,1800,1000])
% saveas(gcf,['FIPS params.png']);

%% 对于每一个被试，绘制其DDM的4参数和alertness的变化情况
warning('记得修改DDM参数与alertness的关系式');

all_alertness=[];
for sub=1:length(step14_alldata)
    subdata=step14_alldata(sub).subdata;
    temp=cat(1,subdata.alertness_info);
    all_alertness=[all_alertness;temp(:,2)];
end
figure;
% hist(all_alertness,50);
alertness_X=linspace(0.5,15,300);

%%
P1=[];
P2=[];
P3=[];
P4=[];
for i=1:size(allparams,1)
    params=allparams(i,:);

%     %适用于fit5 ，fit6 ， fit12  fit13 每个DDM参数都是AB fit   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%     P1(i,:)=params(2).* (  params(1).^alertness_X) ;
%     P2(i,:)=params(4).* (params(3).^alertness_X) ;
%     P3(i,:)=params(6).* (params(5).^alertness_X) ;
%     P4(i,:)=params(8).* (params(7).^alertness_X) ;
%     
    %适用于fit8，fit10 fit15 , 每个DDM参数都使用ABC做fit
%     P1(i,:)=params(1) .*  (alertness_X.^params(2)) + params(3);
%     P2(i,:)= params(4) .*  (alertness_X.^params(5)) + params(6) ;
%     P3(i,:)=params(7) .*  (alertness_X.^params(8)) + params(9) ;
%     P4(i,:)=params(10) .*  (alertness_X.^params(11)) + params(12) ;

        %第9次fit适配，第14次fit适配 也就是drift rate使用3参数同fit8， 其他几个都使用2参数同fit5
    P1(i,:)=params(1) .*  (alertness_X.^params(2)) + params(3);
    P2(i,:)=params(5).* (params(4).^alertness_X) ;
    P3(i,:)=params(7).* (params(6).^alertness_X) ;
    P4(i,:)=params(9).* (params(8).^alertness_X) ;

% % %第11次fit适配，4个DDM参数都使用sigmod
%     P1(i,:) = params(1) ./ ( 1 + exp(( -alertness_X + params(2) ) .* params(3) )) + params(4);
%     P2(i,:) = params(5) ./ ( 1 + exp(( -alertness_X + params(6) ) .* params(7) )) + params(8);
%     P3(i,:) = params(9) ./ ( 1 + exp(( -alertness_X + params(10) ) .* params(11) )) + params(12);
%     P4(i,:)= params(13) ./ ( 1 + exp(( -alertness_X + params(14) ) .* params(15) )) + params(16);
%     
end

% save('P_from_p9','P1','P2','P3','P4');

% [~,order]=sort(P1(:,end)-P1(:,1));
% P1=P1(order,:);
% % P1(1:2,:)=[];
% % P1(end-1:end,:)=[];
% 
% [~,order]=sort(P2(:,end)-P2(:,1));
% P2=P2(order,:);
% % P2(1:2,:)=[];
% % P2(end-1:end,:)=[];
% 
% [~,order]=sort(P3(:,end)-P3(:,1));
% P3=P3(order,:);
% % P3(1:2,:)=[];
% % P3(end-1:end,:)=[];
% 
% [~,order]=sort(P4(:,end)-P4(:,1));
% P4=P4(order,:);
% % P4(1:2,:)=[];
% % P4(end-1:end,:)=[];

figure;

for p=1:4
    subplot(1,4,p);
    hold on
    thisP=eval(['P',num2str(p)]);
    for i=1:size(thisP,1)
        plot(alertness_X,thisP(i,:),'Color',[0.9,0.9,0.9]);
    end
end

subplot(1,4,1);
% shadedErrorBar(alertness_X,mean(P1) , std(P1)/sqrt(size(P1,1)),'lineprops',{'Color',[0,0,0],'LineWidth',2},'patchSaturation',0.33);
% set(gca,'FontWeight','bold');
set(gca,'linewidth',2,'YTick',[0,5,10,15,20],'YTickLabel',{'0','5','10','15','20'});
plot(alertness_X,median(P1),'Color',[1,0,0]);
ylim([0,20]);
ylabel('漂移率均值');
% plot(alertness_X,median(P1,1),'LineWidth',2,'Color',[1,0,0]);
% set(gca,'XScale','log');
set(gca,'FontName','微软雅黑')

subplot(1,4,2);
% shadedErrorBar(alertness_X,mean(P2) , std(P2)/sqrt(size(P2,1)),'lineprops',{'Color',[0,0,0],'LineWidth',2},'patchSaturation',0.33);
% set(gca,'FontWeight','bold');
set(gca,'linewidth',2,'YTick',[0,5,10,15,20],'YTickLabel',{'0','5','10','15','20'});
plot(alertness_X,median(P2),'Color',[1,0,0]);
ylim([0,15])
ylabel('漂移率变异性');
% set(gca,'XScale','log');
% plot(alertness_X,median(P2,1),'LineWidth',2,'Color',[1,0,0]);
set(gca,'FontName','微软雅黑')

subplot(1,4,3);
% shadedErrorBar(alertness_X,mean(P3) , std(P3)/sqrt(size(P3,1)),'lineprops',{'Color',[0,0,0],'LineWidth',2},'patchSaturation',0.33);
% set(gca,'FontWeight','bold');
set(gca,'linewidth',2,'YTick',[0,0.5,1,1.5],'YTickLabel',{'0', '0.5','1' ,'1.5'});
plot(alertness_X,median(P3),'Color',[1,0,0]);
ylim([0,1.5]);
ylabel('最小非反应时间');
% set(gca,'XScale','log');
% plot(alertness_X,median(P3,1),'LineWidth',2,'Color',[1,0,0]);
set(gca,'FontName','微软雅黑')

subplot(1,4,4);
% shadedErrorBar(alertness_X,mean(P4) , std(P4)/sqrt(size(P4,1)),'lineprops',{'Color',[0,0,0],'LineWidth',2},'patchSaturation',0.33);
% set(gca,'FontWeight','bold');
set(gca,'linewidth',2,'YTick',[0,0.5,1,1.5,2],'YTickLabel',{'0', '0.5','1' ,'1.5','2'});
plot(alertness_X,median(P4),'Color',[1,0,0]);
ylim([0,1.5]);
ylabel('非反应时变异性');
% set(gca,'XScale','log');
% plot(alertness_X,median(P4,1),'LineWidth',2,'Color',[1,0,0]);

set(gcf,'Color',[1,1,1])
set(gcf,'position',[100,100,1200,400])

% saveas(gcf,'FIPS params2DDM 0.2-15  Exponential model.svg','svg');

set(gca,'FontName','微软雅黑')
%%