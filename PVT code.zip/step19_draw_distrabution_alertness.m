%绘制多个distrabution，随着alertness增加而变化

clear;clc;
load('fit_with_FIPS_result/第十八次fit/step14_alldata.mat');

sub=35;
%%
figure
hold on
set(gcf,'Color',[1,1,1]);

% params=step14_alldata(sub).fit_with_FIPS_result;

params=cat(1,step14_alldata.fit_with_FIPS_result);
params=mean(params);

alertness_value=[3,5,7,9,15];
colorbank=[0.9,0.7,0.5,0.3,0.1];

for i=1:length(alertness_value)
%     drift_rate_m=params(2) * (  params(1)^alertness_value(i)) ;
%     drift_rate_sd=params(4)* (params(3)^alertness_value(i)) ;
%     ndt=params(6)* (params(5)^alertness_value(i)) ;
%     ndt_range=params(8)* (params(7)^alertness_value(i)) ;
    
    drift_rate_m=params(1) .*  (alertness_value(i).^params(2)) + params(3);
    drift_rate_sd=params(5).* (params(4).^alertness_value(i)) ;
    ndt=params(7).* (params(6).^alertness_value(i)) ;
    ndt_range=params(9).* (params(8).^alertness_value(i)) ;
    
    DDMparams=[drift_rate_m,drift_rate_sd,ndt,ndt_range];
    [~,predict_data]=chi_square_fit_x([],DDMparams,50000);
    
    bins=round((max(predict_data)-min(predict_data))/0.005);
    
    pl=hist_frame_1(predict_data,bins);
    
    pl.Color=repmat(colorbank(i),1,3);
    



end

xlabel('time');
ylabel('frequency');
xlim([0,1.5]);
set(gca,'YTick',[]);
legend({'alertness=3','alertness=5','alertness=7','alertness=9','alertness=15'},'Box','off');
% saveas(gcf,'RT_distr_with_alertness','svg');

