% 整理所有的DDM拟合结果，把拟合结果纳入到alldata里
% 同时对所有DDM的拟合结果重新计算一次chi2，  再计算一次拟合时结果对应的chi2
% 这两个chi2本质是等同的，后者乘以样本数即等于前者

% 再对所有的被试计算一次ddm拟合结果的AIC和BIC值

clear;clc;
allresult=dir(['fit_result/','*.mat']);
load('process_data/alldata.mat');
step5_alldata=alldata;

freedom_degree=4; %每一次PVT任务的chi2结果的自由度， 为bin的数量-1
%%
for s=1:length(step5_alldata)
    thisname=step5_alldata(s).subdir_name;
    load(['fit_result/',thisname]); %得到该被试的 subdata
    if isempty(subdata)
        continue
    end
    
    subdata(1).chi2=[];
    n=0;
    for d=1:length(subdata)    
        if isempty(subdata(d).record)
            continue
        end
        
        record=subdata(d).record;
        params=record(1,5:8);
        
        subdata(d).params=params;  %拟合结果
        subdata(d).chi2=record(1,9);
        
        n=n+1;
    end
    step5_alldata(s).subdata=subdata;
    step5_alldata(s).chi2_df_rate=sum([subdata.chi2])/ (freedom_degree*n-1 ); % 整个被试的所有PVT任务的拟合结果的卡方自由度比， 也就是传统DDM建模的拟合自由度比
    %自由度为每一次PVT任务的自由度之和-1
    
end

%%
save('process_data/step5_alldata','step5_alldata');














