% 对纯DDM的拟合结果进行绘图，

% 从fit_result文件夹里读取拟合结果， 并且把绘图结果保存到fit_result文件夹内
% 每个被试出一张图，每张图里都包含该被试完成的所有run
% 每个图里，蓝色线表示真实数据分布，红色线表示模型拟合数据分布

clear;clc;
addpath('scripts');
allresult=dir(['fit_result/','*.mat']);

freedom_degree=4; %每一次PVT任务的chi2结果的自由度， 为bin的数量-1
%% 绘图

for s=1:length(allresult)
    load(['fit_result/',allresult(s).name]);
    
    thistitle=allresult(s).name;
    
    close all
    figure;
    set(gcf,'position',[0,0,1920,1080])
    try
        subdata(cellfun(@isempty,{subdata.valid_RT}))=[];
    catch
        continue
    end
    
    %% 先计算所有参数的std
    allparams=[];
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT2)
            continue
        end
        record=subdata(d).record;    
        params=record(1,5:8);
        allparams=[allparams;params];
    end
    ps=std(allparams);
    pm=mean(allparams);
    %%
    
    n=0;
    allchi2=[];
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT2)
            continue
        end
        n=n+1;
        
        record=subdata(d).record;
        valid_RT2=subdata(d).valid_RT2;
        params=record(1,5:8);
        
        diff=round((params-pm)./ps,1); %这个参数在被试整个水平里的有多离群？
        
        chi2=record(1,9);
        allchi2=[allchi2,chi2];
        
        [~,data1]=chi_square_fit_x([],params,20000);
        
        subplot(4,8,d);
        cla
        hist_frame_2(data1(data1<4),150,valid_RT2(valid_RT2<4),10)
        xlim([0 2]);
        
        xlabel(['[',num2str(diff),']']);
        title(['chi2/df = ',num2str(round(chi2/freedom_degree,2))]);
        
        
        if d==30
            break
        end
    end
    
    allchi2df=sum(allchi2)/ (freedom_degree*n-1 ); % 
    
    suptitle(['ALL chi2/df = ',num2str(round(allchi2df,2))]);
    
    saveas(gcf, ['fit_result\',thistitle,'.png']  );
    
end
close all

return
