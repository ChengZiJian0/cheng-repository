% 使用FIPS工具包predict了所有被试的alertness以及fitigue结果，并且保存为csv格式
% 其中alertness结果是由TPM模型产生的
% 其中fitigue结果是由unified模型产生的
% 这里将所有csv结果里的alertness以及fitigue结果整理到alldata里

%%
clear;clc;
allFIPS_TPM_result=dir('FIPS/*TPM.csv');
allFIPS_unified_result=dir('FIPS/*unified.csv');

load('process_data/step10_alldata');

step11_alldata=step10_alldata;

%%
for i=1:length(allFIPS_TPM_result)
    thisname=allFIPS_TPM_result(i).name;
    subID=thisname(1:5);
    inx=find(strcmp({step11_alldata.subdir_name},subID));
    sleep_schdule=step11_alldata(inx).sleep_schdule;
    tstart=sleep_schdule(1).tstart;
    
    [~,~,fipscsv]=xlsread(['FIPS/',thisname]);
    alertness=fipscsv(2:end,[7,end]);    
    kss=fipscsv(2:end,[7,end-1]);    
    
    step11_alldata(inx).alertness=alertness;
    step11_alldata(inx).kss=kss;
    
    fprintf('.');
end

%%

for i=1:length(allFIPS_unified_result)
    thisname=allFIPS_unified_result(i).name;
    subID=thisname(1:5);
    inx=find(strcmp({step11_alldata.subdir_name},subID));
    sleep_schdule=step11_alldata(inx).sleep_schdule;
    tstart=sleep_schdule(1).tstart;
    
    [~,~,fipscsv]=xlsread(['FIPS/',thisname]);
    fatigue=fipscsv(2:end,end);
    step11_alldata(inx).fatigue=fatigue;
    fprintf('.');
end

%%
save('process_data/step11_alldata','step11_alldata');










