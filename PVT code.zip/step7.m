% 前一步里已经整理了每一个被试的去程起飞落地 返程起飞落地时刻

% 在这里，提取被试做的所有实验， 并且按照，  去程起飞前，  去程航班中，  落地后间隙，  返程航班中，  返程航班后   五个阶段分类标记，
% 落地后间隙的时长有两种， 一种是落地后仅仅几个小时便返程起飞，另一种是落地后过夜再返程起飞， 注意这两种情况应该分别考虑
% 同时，不考虑起飞前3天以上以及回城落地后三天以后的数据

% 0 去程起飞的3天之前， 不分析
% 1 去程起飞的三天内
% 2 去程航班中
% 3 间隙
% 4 返程航班中
% 5 返程后的三天内
% 6 返程后的三天以后， 不分析

%在这个脚本的后半部分，对被试结果按照标准14次进行整理
%即day1 day2 day3   去程起飞前  飞行中2次  去程落地后   返程起飞前 飞行中2次  返程落地后  day6 day7 day8

clear;clc;
addpath('scripts');
load('process_data/step6_alldata.mat');

step7_alldata=step6_alldata;
%%
%首先观察每一个阶段里的数据数量

for sub=1:131
    subdata=step7_alldata(sub).subdata;
    if isempty(subdata)
        continue;
    end
    
    t1_start=datetime(step7_alldata(sub).t1_start);
    t1_end=datetime(step7_alldata(sub).t1_end);
    t2_start=datetime(step7_alldata(sub).t2_start);
    t2_end=datetime(step7_alldata(sub).t2_end);
    
    for d=1:length(subdata)
        trial_time=datetime(subdata(d).TRIAL_DATE_TIME,'Format','MM-dd-yyyy HH:mm');
        trial_time=datetime(trial_time,'Format','yyyy-MM-dd hh:mm');
        if days(t1_start-trial_time)>3 %如果实验完成时间在起飞3天前，则记录为0
            finish_type=0; %去程起飞3天以前
        elseif  days(trial_time-t2_end)>3
            finish_type=6; %返程3天以上
        elseif trial_time<t1_start
            finish_type=1;    %起飞前3天内
        elseif  trial_time>t1_start   &&   trial_time<t1_end
            finish_type=2;   %去程航班中
        elseif  trial_time>t1_end  &&  trial_time<t2_start
            finish_type=3;  %间隙
        elseif  trial_time>t2_start &&  trial_time<t2_end
             finish_type=4;  %返程航班中
        elseif  trial_time>t2_end 
            finish_type=5;  %返程后的3天内
        end
        step7_alldata(sub).subdata(d).finish_type=finish_type;
    end
end

%%
save('process_data/step7_alldata','step7_alldata');























