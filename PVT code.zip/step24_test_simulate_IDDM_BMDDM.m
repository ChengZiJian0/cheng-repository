% 这里读取的结果是两个模型的交集
% 两个模型都使用完全一样的traindata进行拟合
% 在这里要对完全一样的testdata进行测试



clear;clc;rng('Shuffle');
addpath('scripts');

allmat=dir('cross_validation_BMDDM_IDDM/*.mat');
allmat_BMDDM=dir('cross_validation_BMDDM/*.mat');
bins=5;




% 7
% 11
% 17
% 22
% for sub=1:length(allmat)
sub=7;

thisname=allmat(sub).name;
thisname_BMDDM=allmat_BMDDM(sub).name;


load(['cross_validation_BMDDM_IDDM/',thisname]);
BMDDM=load(['cross_validation_BMDDM/',thisname_BMDDM]);
params_BMDDM=BMDDM.record(1,10:18);
close all

figure;
set(gcf,'position',[10,10,1900,1000]);

all_Tall_BMDDM=[];
all_Tall_IDDM=[];
all_test_data=[];

for d=1:length(subdata)
    record=subdata(d).IDDM_record_same_data_with_BMDDM;
    this_params_IDDM=record(1,5:8);
    
    alertness_value=subdata(d).alertness_info(2);
    drift_rate_m = params_BMDDM(1)*  (alertness_value^params_BMDDM(2)) + params_BMDDM(3) ;
    drift_rate_sd=params_BMDDM(5)* (params_BMDDM(4)^alertness_value) ;
    ndt=params_BMDDM(7)* (params_BMDDM(6)^alertness_value) ;
    ndt_range=params_BMDDM(9)* (params_BMDDM(8)^alertness_value) ;
    this_params_BMDDM=[drift_rate_m ,drift_rate_sd,ndt,ndt_range];
    
    
    test_data=subdata(d).test_data;
    test_data=sort(test_data);
    inx=find(diff(test_data)==0);
    test_data(inx)=test_data(inx)-0.000001; %防止相同的反应时变成边界，导致bin划分不准
    inx=linspace(0.0001,bins,length(test_data));
    inx=ceil(inx);
    bins_end=[];
    for i=1:bins
        thisinx=find(inx==i);
        bins_end(i)=test_data(thisinx(end));
    end
    bins_end(end)=Inf;
    bins_end=[0,bins_end];
    bins_info=[bins_end(1:end-1);bins_end(2:end)];
    data=bins_info;
    % 提前将每一个bin里的观测值记录入data
    for i=1:bins
        inx1=test_data>data(1,i);
        inx2=test_data<=data(2,i);
        O(i)=sum(inx1.*inx2);
    end
    data(3,:)=O;
    
    [chi_square_BMDDM,Tall_BMDDM]=chi_square_fit_x(data,this_params_BMDDM,3000);
    [chi_square_IDDM,Tall_IDDM]=chi_square_fit_x(data,this_params_IDDM,3000);
    
    Tall_BMDDM(Tall_BMDDM>1)=[];
    Tall_IDDM(Tall_IDDM>1)=[];
    
    color1=[0 0.4470 0.7410];
    color2=[0.8500    0.3250    0.0980];
    color3=[0.3250    0.8500  0.0980];
    
    if d<=20
        subplot(4,5,d);
        hist_frame_3(test_data,5,color1,Tall_BMDDM,50,color2,Tall_IDDM,50,color3);
        legend({'test data','BM-DDM','I-DDM'},'box','off');
        xlim([0.15,0.5]);
    end
    
    all_test_data=[all_test_data,test_data];
    all_Tall_BMDDM=[all_Tall_BMDDM,Tall_BMDDM];
    all_Tall_IDDM=[all_Tall_IDDM,Tall_IDDM];
    
end
subplot(4,5,20);
cla
hist_frame_3(all_test_data,10,color1,all_Tall_BMDDM,50,color2,all_Tall_IDDM,50,color3);
xlim([0.15,0.5]);
%     return

% saveas(gcf,['cross_validation_BMDDM_IDDM/',thisname,'.svg']);
% close all
% end










