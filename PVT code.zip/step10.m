% 根据sleep wake time used...xlsx表格， 整理所有被试的作息时间并记录进sleep_schdule字段内
% 这里存在问题，即发现CE的大部分被试的D1和D2存在时间冲突，即D2的入睡时间甚至比D1还要早，或者D2的入睡时间是D1的睡眠期间，
% 这个问题咨询了何老师，答复是D2时间可能时间早了1天，然而数据中D2以及之后的时间都是连续的， 不可能所有时间里都早了一天。
% 因此决定整体删去CE的D1， 因此CE数据只有7天

% SH的数据中基本没有这个情况，因此没有删除D1作息时间数据
% SH本身就只有7天的数据，因此最终记录也是7天

% 另外也有部分被试的其他day里存在时间冲突，这些存在冲突的数据被标记为have_problem=2
% 另外有许多被试的作息时间不全，缺少数据，即不是完整的7天的数据，这些被标记为have_problem=1
% 下一步分析仅考虑have_problem为0的数据

% 比对被试的飞行日期是否位于 睡眠状态记录日期之内，即是否位于7天之内， 如果不在之内说明时间存在问题
% time_check_problem，字段为0表示时间没有问题，  1表示时间存在问题。2表示无信息

%比对被试飞行时间是否是被试的清醒时间，如果飞行时间和被试的睡眠时间重叠，则说明时间存在问题（除非被试可以在飞机上睡觉）
% time_check_problem2，字段为0表示时间没有问题，  1表示时间存在问题。空值表示无信息
% 这一部分的数据里发现大部分被试的飞行时间和睡眠时间都存在重叠， 可能他们真的在飞机上睡觉

%%
clear;clc;
load('process_data/step7_alldata');
[~,~,raw]=xlsread('sleep wake time used with model text generation.xlsx');
CE_raw=raw(2:65,1:26);
SH_raw=raw(66:107, 1:23);

step10_alldata=step7_alldata;

%% 整理CE的作息数据

for sub =1:87
    subID=step10_alldata(sub).subdir_name;
    inx=strcmp(CE_raw(:,1),subID);
    inx=find(inx);
    if isempty(inx)
        continue;
    end
    info=CE_raw(inx,:);
    
    sleep_schdule=[];
    for d=1:8
        sleep_schdule(d).d=d;
        
        sleep_schdule(d).tstart_str=info{3+(d-1)*3};
        sleep_schdule(d).tend_str=info{4+(d-1)*3};
        sleep_schdule(d).dur_str=info{5+(d-1)*3}*24;
        
        try
            sleep_schdule(d).tstart=datetime(info{3+(d-1)*3},'Format','yyyy/MM/dd HH:mm:ss');
        catch ;end
        
        try
            sleep_schdule(d).tend=datetime(info{4+(d-1)*3},'Format','yyyy/MM/dd HH:mm:ss');
        catch ;end
        
        try
            sleep_schdule(d).dur=hours(sleep_schdule(d).tend-sleep_schdule(d).tstart);
        catch ;end
    end
    sleep_schdule(1)=[];  %因为大量被试的D1和D2存在作息冲突，因此删去D1数据
    step10_alldata(sub).sleep_schdule=sleep_schdule;
    
    if length([sleep_schdule.dur])==7
        if any(diff(reshape([[sleep_schdule.tstart];[sleep_schdule.tend]],1,[]))<0)
            step10_alldata(sub).have_problem=2;
        else
            step10_alldata(sub).have_problem=0;
        end
    else
        step10_alldata(sub).have_problem=1;
    end
    
end

%% 整理SH的作息数据  

for sub =88:131
    subID=step10_alldata(sub).subdir_name;
    inx=strcmp(SH_raw(:,1),subID);
    inx=find(inx);
    if isempty(inx)
        continue;
    end
    info=SH_raw(inx,:);
    
    sleep_schdule=[];
    for d=1:7
        sleep_schdule(d).d=d;
        
        sleep_schdule(d).tstart_str=info{3+(d-1)*3};
        sleep_schdule(d).tend_str=info{4+(d-1)*3};
        sleep_schdule(d).dur_str=info{5+(d-1)*3}*24;
        
        try
            sleep_schdule(d).tstart=datetime(info{3+(d-1)*3},'Format','yyyy/MM/dd HH:mm:ss');
        catch ;end
        
        try
            sleep_schdule(d).tend=datetime(info{4+(d-1)*3},'Format','yyyy/MM/dd HH:mm:ss');
        catch ;end
        
        try
            sleep_schdule(d).dur=hours(sleep_schdule(d).tend-sleep_schdule(d).tstart);
        catch ;end
    end
    step10_alldata(sub).sleep_schdule=sleep_schdule;
    
    if length([sleep_schdule.dur])==7
        if any(diff(reshape([[sleep_schdule.tstart];[sleep_schdule.tend]],1,[]))<0)
            step10_alldata(sub).have_problem=2;
        else
            step10_alldata(sub).have_problem=0;
        end
    else
        step10_alldata(sub).have_problem=1;
    end
    
end

%%  比对被试的飞行日期是否位于 睡眠状态记录日期之内， 如果不在之内说明时间存在问题
for sub=1:131
    step10_alldata(sub).time_check_problem=2;
    try
        step10_alldata(sub).all_dur_days=days(step10_alldata(sub).sleep_schdule(end).tend - step10_alldata(sub).sleep_schdule(1).tstart);
    catch
        step10_alldata(sub).all_dur_days=[];
    end
    
    try
        t2_end=datetime(step10_alldata(sub).t2_end,'format','yyyy-MM-dd HH:mm:ss');
        exp_end= step10_alldata(sub).sleep_schdule(end).tend ;
        t1_start=datetime(step10_alldata(sub).t1_start,'format','yyyy-MM-dd HH:mm:ss');
        exp_start = step10_alldata(sub).sleep_schdule(1).tstart;
        
        inx1=exp_end>t2_end;
        inx2=t2_end>t1_start;
        inx3=t1_start>exp_start;
        
        step10_alldata(sub).time_check=[inx1,inx2,inx3];
        if any([inx1,inx2,inx3]==0)
            step10_alldata(sub).time_check_problem=1;
        else
            step10_alldata(sub).time_check_problem=0;
        end
    catch
    end
end
save('process_data/step10_alldata','step10_alldata');

%% 比对被试飞行时间是否是被试的清醒时间，如果飞行时间和被试的睡眠时间重叠，则说明时间存在问题（除非被试可以在飞机上睡觉
% 这部分代码无需执行，因为不用作数据筛除
for sub=1:131
    if step10_alldata(sub).time_check_problem==0 %如果时间检查没有问题， 则进一步检查
        
        t1_start=datetime(step10_alldata(sub).t1_start,'format','yyyy-MM-dd HH:mm:ss');
        t1_end=datetime(step10_alldata(sub).t1_end,'format','yyyy-MM-dd HH:mm:ss');
        t2_start=datetime(step10_alldata(sub).t2_start,'format','yyyy-MM-dd HH:mm:ss');
        t2_end=datetime(step10_alldata(sub).t2_end,'format','yyyy-MM-dd HH:mm:ss');
        
        sleep_schdule=step10_alldata(sub).sleep_schdule;
        
        ok1=0;
        for d=1:length(sleep_schdule)-1
            inx1=t1_start>sleep_schdule(d).tend;
            inx2=t1_end<sleep_schdule(d+1).tstart;
            if inx1+inx2==2
                ok1=1;
                break;
            end
        end
        
        ok2=0;
        for d=1:length(sleep_schdule)-1
            inx1=t2_start>sleep_schdule(d).tend;
            inx2=t2_end<sleep_schdule(d+1).tstart;
            if inx1+inx2==2
                ok2=1;
                break;
            end
        end
        
        
        step10_alldata(sub).time_check2=[ok1,ok2];
        if any([ok1,ok2]==0)
            step10_alldata(sub).time_check_problem2=1;
        else
            step10_alldata(sub).time_check_problem2=0;
        end
    end    
end


%%  把睡眠状态的时间序列信息整理成excel
mkdir('unit_sequence');
for sub=1:length(step10_alldata)
    if step10_alldata(sub).time_check_problem==0  && step10_alldata(sub).have_problem==0
        
        sleep_schdule=step10_alldata(sub).sleep_schdule;
        
        task_dur=minutes(sleep_schdule(end).tend-sleep_schdule(1).tstart); %从报告的第一次睡觉，到最后一次睡眠结束的分钟数
        task_dur=task_dur+600 ; %在这个基础上增加10小时的清醒时间
        unit_sequence=ones(1,round( task_dur /10));  %每10分钟计算一次清醒度或者疲劳度，即一个睡眠点为10分钟
        sequence_start=datestr(sleep_schdule(1).tstart,31);
        
        for d=1:length(sleep_schdule)
            s=round(minutes(sleep_schdule(d).tstart-sleep_schdule(1).tstart)/10)+1; %每一次入睡时刻为整个睡眠序列的第几个点
            dur=round(sleep_schdule(d).dur*60/10);
            unit_sequence(s:s+dur)=0;
        end
        
        unit_sequence=mat2cell(unit_sequence',ones(length(unit_sequence),1),1);
        unit_sequence=cat(1,'a',unit_sequence);
        unit_sequence{1,2}='start_time';
        unit_sequence{2,2}=sequence_start;
        
        xlswrite(['unit_sequence/',step10_alldata(sub).subdir_name,'.xlsx'],unit_sequence);
        
    end
    fprintf('.');
    
end


%% 接下来交给FIPS工具包来计算每个时间点下的alertness和fatigue值

















