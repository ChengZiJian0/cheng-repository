function step3_fit_data(substart,subend)
% 对SH CE两部分数据逐被试、逐run 的进行拟合
% 下一步拟合应当联合被试，对不同时间段的所有被试数据进行拟合
% 此处的拟合使用DDM模型对被试的每一次PVT任务都分别独立进行拟合

load('process_data/alldata.mat');

delete(gcp('nocreate'));
parpool(5);

bins=5;
addpath('scripts');addpath('scripts/bads-master');

if subend>length(alldata) || substart >length(alldata) ||  substart >subend
    error('substart and subend error')
end

alldata=alldata(substart:subend);
%%
for s=1 : length(alldata)
    subdata=alldata(s).subdata;
    for d=1:length(subdata)
        subdata(d).record=[];
        valid_RT2=subdata(d).valid_RT2;
        if isempty(valid_RT2)
            continue
        end
        record=fit_fun_bads(valid_RT2,bins);
        
        subdata(d).record=record;
    end
    save(['fit_result/', alldata(s).subdir_name],'subdata')

end


