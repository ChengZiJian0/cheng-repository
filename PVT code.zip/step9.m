这个脚本不需要运行，因为绘制结果没有什么意义
%绘制结果，与step8不同的地方是，这个脚本里对所有的fit结果进行绘制， 不会对一个被试的一个阶段的结果进行平均
% 因为不同被试参加的航班时长不同(9-13小时)， 且休息间隔也不同（2-5小时， 或者超过24小时），
% 这里的图会按照最长时长的航班(13小时)，以及最长的休息间隔（5小时）来进行绘制

% 对于每一个阶段， 都将数据按照时间顺序分成若干份，并且计算每一份内的均值，以观察参数变化情况

clear;clc;load('alldata');

subrange=1:87;
figure_prefix='CE';

%%
R={};
for sub=1:131
    
    subdata=alldata(sub).subdata;
    if isempty(subdata)
        continue;
    end
    if alldata(sub).gap_dur>10
        continue;
    end
    
    t1_start=datetime(alldata(sub).t1_start);
    t1_end=datetime(alldata(sub).t1_end);
    t2_start=datetime(alldata(sub).t2_start);
    t2_end=datetime(alldata(sub).t2_end);
    
    temp1={}; %分别记录每个阶段内的多次实验结果， 第一行为实验完成时间戳，其0点为该阶段的开始时刻， 第二行为实验拟合参数
    temp2={};
    temp3={};
    temp4={};
    temp5={};
    
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT)
            continue;
        end
        
        d_time=datetime(subdata(d).TRIAL_DATE_TIME,'InputFormat','MM-dd-yyyy HH:mm'); %完成一个trial的时间
        
        if subdata(d).finish_type==1  %去程起飞前3天为0点，这个阶段使用72个小时来记录实验信息
            temp1=cat(2,temp1,{72-hours(t1_start-d_time);subdata(d).params});
            
        elseif subdata(d).finish_type==2  %去程起飞为0点，弹性计时，时长为去程航班时长
            temp2=cat(2,temp2, { hours(d_time-t1_start );  subdata(d).params} );
            
        elseif subdata(d).finish_type==3 %去程到达为0点，弹性计时，时长为间隙时长
            temp3=cat(2,temp3, { hours(d_time-t1_end);  subdata(d).params} );
            
        elseif subdata(d).finish_type==4 %返程起飞为0点，弹性计时，时长为返程航班时长
            temp4=cat(2,temp4, { hours(d_time-t2_start) ;  subdata(d).params} );
            
        elseif subdata(d).finish_type==5  %返程到达为0点，这个阶段使用72个小时来记录实验信息
            temp5=cat(2,temp5, { hours(d_time-t2_end);  subdata(d).params} );
            
        end
    end
    
    R{sub,1}=temp1;
    R{sub,2}=temp2;
    R{sub,3}=temp3;
    R{sub,4}=temp4;
    R{sub,5}=temp5;
    
end

%%

temph=linspace(0,1,31);
temph(end)=[];
tempv=linspace(0.2,0.8,5);
list=fullfact([30,5]);

colorlist=[temph(list(:,1));  ones(1,30*5)*0.5  ; tempv(list(:,2)) ];
colorlist=hsv2rgb(colorlist');

colorlist=mat2cell(colorlist,ones(1,150),3);
R(:,6)=colorlist(1:131); %为每一个被试赋值一个单独的颜色

%%

pname={'drift rate Mean','drift rate Std','non-decision time','ndt range'};

for p=1:4
    
    close all
    figure
    
    for s=1:5
        subplot(1,5,s);
        hold on
        
        RR=[];
        for sub=subrange
            subcolor=R{sub,6};
            this=R{sub,s};
            
            if isempty(this)
                continue
            end
            for d=1:size(this,2)
                RR=[RR,[this{1,d};this{2,d}(p)]];
                plot(this{1,d},this{2,d}(p),'o','Color', subcolor)
            end
        end
        
        %每个阶段记录一次RR，RR记录了这个阶段里所有被试完成的所有实验的时间点和参数结果
        
        RR=sortrows(RR',1);
        if s==1 || s==5  %在第一阶段或者第5阶段，每24小时进行一次平均值计算，也就是将时间段分为3份
            
            x1=12;
            x2=36;
            x3=60;
            y1=mean(RR(RR(:,1)<24,2));
            y2=mean(RR(24<RR(:,1) & RR(:,1)<48,2));
            y3=mean(RR(RR(:,1)>48,2));
            plot([0,24],[y1,y1],'Color','red');
            plot([24,48],[y2,y2],'Color','red');
            plot([48,72],[y3,y3],'Color','red');
            
        else   %对2、3、4 阶段的数据按数据数量分成若干份， 每一份计算一次均值
            
            %这一段可以把 2 3 4阶段的时间分成3份
            half_inx=round(size(RR,1)/3);
            y1=mean(RR(1:half_inx,2));
            y2=mean(RR(half_inx+1:half_inx*2,2));
            y3=mean(RR(half_inx*2+1:end,2));            
            plot([RR(1,1),RR(half_inx,1)],[y1,y1],'Color','red');
            plot([RR(half_inx,1),RR(half_inx*2,1)],[y2,y2],'Color','red');
            plot([RR(half_inx*2,1),RR(end,1)],[y3,y3],'Color','red');
            
%             %这一段可以把 2 3 4阶段的时间分成2份
%             half_inx=round(size(RR,1)/2);
%             y1=mean(RR(1:half_inx,2));
%             y2=mean(RR(half_inx+1:end,2));
%             plot([RR(1,1),RR(half_inx,1)],[y1,y1],'Color','red');
%             plot([RR(half_inx,1),RR(end,1)],[y2,y2],'Color','red');
            
        end
 
        if p==1
            ylim([0,20]);
        elseif p==2
            ylim([0,10]);
        elseif p==3
            ylim([0,1]);
        elseif p==4
            ylim([0,3]);
        end
        
        if s==1
            ylabel(pname{p});
            xlabel('时间,  单位: 小时');
            title('起飞前3天');
            xlim([0,72]);
            set(gca,'XTick',[0,24,48,72],'XTickLabel',{'0','24','48','72'})
        elseif s==2
            title('去程飞行中');
            set(gca,'YTick',[],'YTickLabel',{})
            xlabel('时间,  单位: 小时');
        elseif s==3
            title('间隙');
            set(gca,'YTick',[],'YTickLabel',{})
            xlabel('时间,  单位: 小时');
        elseif s==4
            title('返程飞行中');
            set(gca,'YTick',[],'YTickLabel',{})
            xlabel('时间,  单位: 小时');
        elseif s==5
            title('返程落地后');
            xlim([0,72]);
            set(gca,'XTick',[0,24,48,72],'XTickLabel',{'0','24','48','72'})
            set(gca,'YTick',[],'YTickLabel',{})
            xlabel('时间,  单位: 小时');
        end
        
    end
    
    suptitle(['参数',pname{p},'的分阶段结果']);
    set(gcf,'position',[0,0,1900 1000]);
    saveas(gcf, [ figure_prefix,'-params-time-',pname{p},'.png']);
    
end

close all











