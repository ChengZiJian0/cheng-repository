%%
% 读取CE_data和SH_data，并且对数据做筛选，
% 最后将两份数据整理并保存为alldata

% 上航SH共44个被试，
%  其中被试的反应类别里， FS表示被试按键，但超过了5秒

% 东航CE共87个被试  其中：
% ERR表示被试反应，但使用了错误的指头按键
% ET表示被试超时未反应（超过10秒）
% FS表示被试虚报（反应时间低于100ms）

% 东航数据筛选标准如下：
% 去除FS、ERR、ET数据
% 一个run里，如果异常数据（FS、ERR、ET）超过20%，则不做分析
% 一个run里，被纳入分析的数据少于30个，则不做分析
% 去除大于10秒的数据，这里所指的大于10秒的数据只有一例，其值为930058ms

%上航的数据筛选标准如下：
% 只保留反应类别为click的数据，另外的shake类别表示被试通过摇晃手机做反应，这些数据被扔掉
% 一个run里，有效数据占比低于80%，则不做分析
% 一个run里，被纳入分析的数据少于30个，则不做分析

% valid_RT记录了上述标准下的剔除后结果 ，注意valid_RT的单位是秒，不是毫秒
% valid_RT2则基于valid_RT进一步剔除了小于0.15秒的以及大于2.5个标准差的结果


% 最后CE和SH两个数据被整理到同一个文件下，
% 字段r记录了一个被试在所有时间段内的valid_RT数据，单位: 秒
% 字段r2记录了一个被试所有时间段内的valid_RT2数据， 单位：秒


clear;clc; addpath('scripts');
%%

load('process_data/CE_data.mat');
for s=1:length(CE_alldata)
    thissubdata=CE_alldata(s).subdata;
    
    r=[];
    r2=[];
    for d=1:length(thissubdata)
        CE_alldata(s).subdata(d).valid_RT=[];
        CE_alldata(s).subdata(d).valid_RT2=[];
        
        result=thissubdata(d).result;
        
        inx=~cellfun(@isnumeric,{result.subres});
        if mean(inx)>0.2
            continue
        end
        
        valid_RT=[];
        for trial=1:length(result)
            if isnumeric(result(trial).subres)
                if result(trial).subres>10000
                    continue
                end
                valid_RT=[valid_RT,result(trial).subres/1000];
            end
        end
        if length(valid_RT)<40
            continue
        end
        
        r=[r,valid_RT];
        
        valid_RT2=valid_RT;
        valid_RT2(valid_RT2<0.15)=[];
        valid_RT2(valid_RT2>(mean(valid_RT2)+std(valid_RT2)*2.5))=[];
        if length(valid_RT2)<40
            valid_RT2=[];
        end
        
        r2=[r2,valid_RT2];
        CE_alldata(s).subdata(d).valid_RT=valid_RT;
        CE_alldata(s).subdata(d).valid_RT2=valid_RT2;

    end
    CE_alldata(s).r=r;
    CE_alldata(s).r2=r2;
end

% save('CE_data','CE_alldata');

%% SH
load('process_data/SH_data.mat');

for s=1:length(SH_alldata)
    thissubdata=SH_alldata(s).subdata;
    
    r=[];
    r2=[];
    for d=1:length(thissubdata)
        SH_alldata(s).subdata(d).valid_RT=[];
        SH_alldata(s).subdata(d).valid_RT2=[];
        
        result=thissubdata(d).result;

        if isempty(result)
            continue
        end
        
        if length([result.subres])/length(result)<0.8
            continue
        end
        
        valid_RT=[];
        for trial=1:length(result)
            if isnumeric(result(trial).subres) &&  strcmp(result(trial).resp_type,'click') 
                if result(trial).subres>10000
                    continue
                end
                valid_RT=[valid_RT,result(trial).subres/1000];
            end
        end
        if length(valid_RT)<40
            continue
        end
        
        valid_RT2=valid_RT;
        valid_RT2(valid_RT2<0.15)=[];
        valid_RT2(valid_RT2>(mean(valid_RT2)+std(valid_RT2)*2.5))=[];
        if length(valid_RT2)<40
            valid_RT2=[];
        end
        
        r2=[r2,valid_RT2];
        
        r=[r,valid_RT];
        SH_alldata(s).subdata(d).valid_RT=valid_RT;
        SH_alldata(s).subdata(d).valid_RT2=valid_RT2;
        
    end
    SH_alldata(s).r=r;
    SH_alldata(s).r2=r2;
end

% save('SH_data','SH_alldata');

%%
[CE_alldata.data_t]=deal('CE');
[SH_alldata.data_t]=deal('SH');
alldata=cat(2,CE_alldata,SH_alldata);
save('process_data/alldata','alldata');

