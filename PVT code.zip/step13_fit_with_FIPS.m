%
% 第一次拟合
% 指定被试的4参数与alertness的关系为幂函数，则每一个参数可以由两个数值来基于alertness计算，
% 假设 漂移率均值= alertness^a +b，  其中a为正数，且预期在 0-1之间，
% 这意味着随着alertness增加，漂移率均值也会增加，且增加幅度逐渐减小
% b为正数，从而漂移率均值不可能小于0， 设定为0-20之间
% 假设 漂移率标准差= alertness^a +b，  其中a为负数，预期在-1-0之间，
% 这意味着随着alertness增加，漂移率标准差会降低，且降低幅度逐渐减小
% b为正数，从而漂移率均值不可能小于0，设定为0-15之间
%假设ndt与alertness的关系同上，考虑到ndt本身是非常小的， 因此将b的范围设定在0-1之间
% ndt-range 与alertness的关系同上，考虑到ndt-range本身非常小的， 因此将b的范围设定在0-1之间

%第二次fit
% 与第一次一样假定为幂函数关系
% 把这里所有的a的区间设定成-2到2之间，  
% 也就是包含了 随着alertness  ddm参数会增加且增加幅度增大或减小，
% 以及ddm参数会减小且减小幅度会增大或减小 一共四种情况

% 第三次fit
% 假定8参数和4ddm参数之间是1次函数的关系
% 假设 任意DDM参数= alertness*a +b，  其中a为-5到5之间，b为-20到20之间，
% 这次拟合的结果完全没有意义，因为根据拟合结果所计算出来的drift-rate SD都小于0，  ndt小于0, range也小于0
% 应该修改拟合程序，使得这些参数小于0时直接给出惩罚
% 但是这个尝试暂时放弃了，因为这直接导致程序无法进行拟合

% 第四次fit
% 仍然决定使用幂函数，因为幂函数可以在正数范围内制造出“随alertness增大而增大，或者随alertness降低而降低”的效果
% 所有关系都必须限制在正数范围内
% 在这里假定  任意DDM参数= b * alertness^a;
% 其中a为-2到2之间，  b为0.001到50之间

% 第5次fit
% 假定关系为指数函数   任意DDM参数 P = a ^ alertness  * b
% 其中，a的值可以为0-1.5， 当a小于1时， 函数单调递减，  当a大于1时，函数单调递增，   但P始终大于0
% b作为scale， 也可以理解为截距，因为当alertness为0时， P=b，  由此，参数b可以认为是被试在最低清醒度下的极端DDM参数
% 对于DRM， b可以设定为0.001-10
% 对于DRS，b可以设定为1-20
% 对于ndt，b可以设定为0.1 - 5
% 对于ndt range，b可以设定为0.1 - 5 
%  在这个假设中，  当alertness增加， 可以预期SD NDT  range都会降低，且降低速度减缓
%  这个假设中，当alertness增加， 也可以预期 drift rate mean会增加，但其增加幅度必然是越来越大的
%  在这个函数里， 自变量和因变量的关系可以较为接近一次函数
% 目前这次fit的结果表现较好

% 第六次fit
% 一个想法， fit4和fit5都会呈现一个效果，就是 较大的a会配对产生较小的b，这是一个合理的trade off关系
% 因此可以寻找一个合理的b的区间，使得模型更容易倾向产生较大或者较小的a。
% 可以对fit4和fit5进行第二阶段的拟合，观察该效果
% 假定关系和第五次一样，即任意DDM参数 P = a ^ alertness  * b
% 其中a的值仍然为0-1.5
% % 对于DRM， b可以设定为0.1-5，  也就是认为，如果alertness达到最低点，则drift rate mean最大为5，最低为0.1
% 对于这一部分：0.1-5的范围，或许可以通过前期单独拟合的DRM值和alertness结果做回归，然后预测alertness为0时候，再观察DRM的值
% 对于DRS，b可以设定为1-20， 
% 对于ndt，b可以设定为0.2 - 3 ，   也就是认为，如果alertness达到最低点，则ndt会在0.1-3之间
% 对于ndt range，b可以设定为0.1 - 5 
% 结果并未如预期， 可以说表现很差

% 第七次fit
% fit过程和第五次一样，但是使用的数据是FIPS给出的kss预测值
% kss预测值和alertness几乎是刚好相反， 因为是疲劳度的预测，然而有一个差异性，即在刚睡醒的极短时间里，kss会有一个高困倦度，但很快就会降下来
% 因此在这个fit里，预期会得到和第五次fit刚好相反的结果
% 拟合结果发现非常有问题，完全没有得到预期结果，需要进一步检查

% 第8次fit
% 对于四个参数，假设其值与alertness呈幂函数关系， 即
% p= a * alertness ^ b  + c;
% a为正或者负，决定了参数随alertness增加还是减少
% b为正， 当b大于1时， p随alertness加快升高， 当b小于1大于0，p随alertness减速升高
% c为正

% 第9次fit
% 对于漂移率，假设其值与alertness呈幂函数关系， 和第8次fit一样
% 对于其他几个参数，假设参数与alertness仍然为指数函数关系（和第5次fit一样）

% 第10次fit，  与第8次fit一样，但使用的数据是更新后的78人版本（2023.9.19更新的）

%第11次fit， 假定关系为sigmod函数： P = scale./(1+exp((-alertness+u)*k))+b;
%scale决定了整体的宽度,  u决定对称中心的x轴位置，  k决定斜率， b决定整体的高度， 
% scale  -20到20之间
% u  在0到20之间
% k  在0.1-2之间
% b  在0-10之间

% 第12次fit，与第5次fit一样，但使用的数据是更新后的76人版本（2023.9.19更新） 2222

% 第13次fit
% 采用与第5次fit一样的p8模型，使用的数据与DDM模型的第八次拟合一致，且拟合代码的chi2算法有更新
% 同时使用的睡眠数据也是更新后的78人版本

% 第14次fit
% 采用与第9次fit一样的p9模型，使用的数据与DDM模型的第八次拟合一致，且拟合代码的chi2算法有更新
% 同时使用的睡眠数据也是更新后的78人版本

% 第15次fit
% 采用与第8次fit一样的p12模型，使用的数据与DDM模型的第八次拟合一致，且拟合代码的chi2算法有更新
% 同时使用的睡眠数据也是更新后的78人版本

% 第16次fit
% 采用与第11次fit一样的p16模型，使用的数据与DDM模型的第八次拟合一致，且拟合代码的chi2算法有更新
% 同时使用的睡眠数据也是更新后的78人版本
% pvt1-4


% 第17次fit
% 采用p8模型， 使用的数据与DDM的第8次拟合一致
% 使用的睡眠数据是更新后的78人版本
% 因部分被试PVT不满10个，因此实际参与拟合人数为70人
% 拟合时采样数量提高到5000个（之前都是1000）

% 第18次fit
% 采用p9模型， 其他配置与第17次一致

% 第19次fit
% 采用p12模型， 其他配置与第17次一致

% 第20次fit
% 采用p16模型， 其他配置与第17次一致


function step13_fit_with_FIPS(substart,subend)

clc;addpath('scripts');addpath('scripts/bads-master');
load('step12_alldata_forFIPS_fit.mat');
alldata=step12_alldata_forFIPS_fit;

%%
% bounds=[0 ,    0.1 ,   0  , 1   ,   0   ,  0.1 ,   0  ,  0.1;
%                  1.5 , 10   , 1.5 , 20 ,  1.5 ,   5   , 1.5 ,   5   ];
%              P = a ^ alertness  * b

% bounds=[-5 ,    0  ,  0   ,      -5 ,   0 ,  0  ,       -5 , 0  ,  0  ,      -5 , 0  , 0  ;
%                    5 ,    2  , 10  ,       5 ,   2  ,10 ,         5 , 2  ,  2  ,       5 , 2  , 2 ];
               % p= a * alertness ^ b  + c;
               
bounds=[-5 ,    0  ,  0    ,     0     , 1   ,    0    ,  0.1 ,   0  ,  0.1;
                    5 ,    2  , 10    ,  1.5  , 20  ,  1.5  ,    5   , 1.5 ,   5   ];
% 

% bounds=[-20 ,    0  ,  0.1   ,0   ,          -20 ,    0  ,  0.1   ,0   ,       -20 ,    0  ,  0.1   ,0   ,         -20 ,    0  ,  0.1   ,0  ;
%                    20 ,    20  , 2  ,   10 ,          20 ,    20  , 2  ,   10 ,         20 ,    20  , 2  ,   10 ,           20 ,    20  , 2  ,   10 ];
%  P = scale./(1+exp((-alertness+u)*k))+b;
%%
alldata=alldata(substart:subend);
delete(gcp('nocreate'));
parpool(5);

%%
for sub=1:length(alldata)
    if isempty(alldata(sub).r)  || isempty(alldata(sub).alertness)
        continue;
    end
    
    subdata=alldata(sub).subdata;
    subdata(cellfun(@isempty,{subdata.alertness_info}))=[];
    subdata(cellfun(@isempty,{subdata.params}))=[];
    subdata(cellfun(@isempty,{subdata.valid_RT2}))=[];
    
    fitfun=@(params) fit_with_alertness_9(subdata,params);
    
    record=[];
    tic;
    parfor i=1:5
        range=bounds(2,:)-bounds(1,:);
        params=rand(1,length(range)).*range+bounds(1,:);
        [x1,fval,exitflag] = bads(fitfun,params,bounds(1,:),bounds(2,:),bounds(1,:),bounds(2,:));
        record(i,:)=[params,x1,fval,exitflag];
    end
    toc;
    
    record=sortrows(record,size(record,2)-1);
    
    save(['fit_with_FIPS_result/', alldata(sub).subdir_name],'record')
end


