%  对所有被试基于FIPS拟合结果绘制predict结果，  其中每个被试一张大图， 最后一个子图是该被试所有数据的汇集结果

clear;clc;
addpath('scripts');
thispath='第十九次fit';
load(['fit_with_FIPS_result\',thispath,'\step14_alldata.mat']);

% de_inx=[step14_alldata.chi2_df_rate_FIPS]>100;
step14_alldata(de_inx)=[];

[~,index] = sortrows([step14_alldata.chi2_df_rate_FIPS].'); step14_alldata = step14_alldata(index(end:-1:1)); clear index
%%

for sub=1:length(step14_alldata)
    if isempty(step14_alldata(sub).fit_with_FIPS_result)
        continue
    end
    
    thistitle=step14_alldata(sub).subdir_name;
    close all
    figure;
    set(gcf,'position',[0,0,1920,1080])
    
    subdata=step14_alldata(sub).subdata;

    all_predict_data=[];
    all_valid_RT=[];
    params=[];
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT2) || isempty(subdata(d).alertness_info)
            continue;
        end
        valid_RT=subdata(d).valid_RT2;
        all_valid_RT=[all_valid_RT,valid_RT];
        params=subdata(d).ddm_params_by_FIPS;
        [~,predict_data]=chi_square_fit_x([],params,10000);
        all_predict_data=[all_predict_data,predict_data];
        subplot(3,10,d);
        
        hist_frame_2(predict_data(predict_data<4),100,valid_RT(valid_RT<4),10)
        if d==29
            break
        end
    end
    
    subplot(3,10,30);
    
    if isempty(all_predict_data)
        continue
    end
    hist_frame_2(all_predict_data(all_predict_data<4),100,all_valid_RT(all_valid_RT<4),50)
    xlabel('response time')
    ylabel('frequency');
    
    suptitle([thistitle,' = ',num2str(round(step14_alldata(sub).chi2_df_rate_FIPS,2))]);
    
    %     all_data1
    saveas(gcf, ['fit_with_FIPS_result\',thispath,'\',thistitle,'.png']  );
    
end

close all



