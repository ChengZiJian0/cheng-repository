%  对个被试的每一个PVT实验进行一次ddm拟合的nll计算， 再计算每个被试的总的AIC和BIC
 
clear;clc; rng('Shuffle'); addpath('scripts');
load('process_data/step12_alldata_forFIPS_fit.mat');

%% 
sample_num=100000; %采样数量， 这个值不能随意修改
bin_width=0.05; %单个bin的宽度， 这个值不能随意修改
%上面两个参数不可随意修改， 因为会影响到计算出的nll结果，目前所有模型的nll均使用上述参数进行
%只有保证所有模型和数据都使用同样的sample_num和bin_width，才可以进行模型比较

for sub=1:length(step12_alldata_forFIPS_fit)
    subdata=step12_alldata_forFIPS_fit(sub).subdata;
    for d=1:length(subdata)
        allRT=subdata(d).valid_RT2;
        params=subdata(d).params;
        nll=gene_nll(params,sample_num,bin_width,allRT);
        subdata(d).ddm_nll=nll;
    end
    step12_alldata_forFIPS_fit(sub).subdata=subdata;

    params_num=d*4; 
    n =sum(cellfun(@length,{subdata.valid_RT2}));%所有的试次数量
    step12_alldata_forFIPS_fit(sub).ddm_AIC=sum([subdata.ddm_nll]) *2 + 2 * params_num ;  
    step12_alldata_forFIPS_fit(sub).ddm_BIC=sum([subdata.ddm_nll]) *2 +   log(n) * params_num; 
    step12_alldata_forFIPS_fit(sub).n=n;
    disp(sub);
end

save(['process_data/step12_alldata_forFIPS_fit.mat']);