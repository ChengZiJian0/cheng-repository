% 计算警觉度与4个参数的线性回归关系
% 绘制结果

clear;clc;
addpath('scripts');
load('process_data/step12_alldata_forFIPS_fit');

%%
allparams={};
for sub=1:length(step12_alldata_forFIPS_fit)
    subdata=step12_alldata_forFIPS_fit(sub).subdata;
    alertness_info=cat(1,subdata.alertness_info);
    params=cat(1,subdata.params);
    allparams{sub}=[alertness_info(:,2),params];
end

all=cat(1,allparams{:});
Y=all(:,1);
n=length(Y);
X=[ones(n,1),all(:,2:5)];


%%
[b,bint,r,rint,stats] =regress( Y , X ,0.05 );
[beta,stats,t,p]=my_regress(Y,X);
% R-square  
% F statistic 
% p value for the full model, 
% estimate of the error variance.

figure
b=bar(1:5,b);
b.FaceColor=[1,1,1];
b.LineWidth=2;

hold on
eb=errorbar(1:5, mean(bint') , [bint(:,2)-bint(:,1)]'    ,'Linestyle','None','linewidth',2,'Color',[0.3,0.3,0.3]);

xticklabel={'beta 0','beta v','beta η','beta T_e_r','beta S_t'};
round(p,2)

% for i=1:4
%     xticklabel{i+1}=[xticklabel{i+1},'\newline','p=',num2str(round(p(i),2))];
% end

set(gca,'XTick',1:5,'XTickLabel', xticklabel);

set(gcf,'Color',[1,1,1]);
set(gca,'LineWidth',2,'FontWeight','bold');
set(gca,'Box','off');

legend(eb,{'95% interval'},'Box','off');

% saveas(gcf,'alertness_regress_with_ddm2','svg');

return 
%%

allbeta=[];
for sub=1:length(step12_alldata_forFIPS_fit)
    subdata=step12_alldata_forFIPS_fit(sub).subdata;
    alertness_info=cat(1,subdata.alertness_info);
    params=cat(1,subdata.params);
    
    Y=alertness_info(:,2);
    X=[ones(length(subdata),1),params];
    
    [beta,stats,t,p]=my_regress(Y,X);
    allbeta=[allbeta;beta'];

    
end

figure;
hold on
xticklabel={'beta 0','beta V','beta η','beta ndt','beta ndt-range'};
bar(1:5,mean(allbeta))
set(gca,'XTick',1:5,'XTickLabel', xticklabel);


for i=1:5
    x=randn(length(step12_alldata_forFIPS_fit),1)*0.1;
    x=x+i;
    scatter(x,allbeta(:,i))
    
end



set(gcf,'Color',[1,1,1]);
set(gca,'LineWidth',2,'FontWeight','bold');
set(gca,'Box','off');







