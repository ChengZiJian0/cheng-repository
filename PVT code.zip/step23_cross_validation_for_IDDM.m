function step23_cross_validation_for_IDDM(substart,subend)

alldata=dir('cross_validation_BMDDM/*.mat');
alldata=alldata(substart:subend);

delete(gcp('nocreate'));
parpool(5);

bins=5;
addpath('scripts');addpath('scripts/bads-master');

%%
for s=1 : length(alldata)
    load(['cross_validation_BMDDM/',alldata(s).name]);
    for d=1:length(subdata)
        train_data=subdata(d).valid_RT2; %这里读取的是step21里的BMDDM的train数据
        if isempty(train_data)
            continue
        end
        record=fit_fun_bads(train_data,bins);
        subdata(d).IDDM_record_same_data_with_BMDDM=record; %这里的record是对BMDDM的train data进行的IDDM的拟合结果..
    end
    save(['cross_validation_BMDDM_IDDM/', alldata(s).name],'subdata','-append');
end


