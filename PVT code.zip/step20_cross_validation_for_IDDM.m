% 这个脚本与step3是一样的
% 使用的数据也是一样的，
% 但是在拟合的时候，把数据分成了两部分， 一部分用于train，另一部分作为test数据保存下来
% 在后面的分析中，会使用train数据的拟合参数结果，去计算test数据的卡方值自由度



function step20_cross_validation_for_IDDM(substart,subend)

load('process_data/alldata.mat');

delete(gcp('nocreate'));
parpool(5);

bins=5;
addpath('scripts');addpath('scripts/bads-master');

if subend>length(alldata) || substart >length(alldata) ||  substart >subend
    error('substart and subend error')
end

alldata=alldata(substart:subend);
%%
for s=1 : length(alldata)
    subdata=alldata(s).subdata;
    for d=1:length(subdata)
        subdata(d).record=[];
        valid_RT2=subdata(d).valid_RT2;
        
        if isempty(valid_RT2)
            continue
        end
        
        inx=round(length(valid_RT2)*0.5); %用于train的数据数量
        valid_RT2=Shuffle(valid_RT2);
        train_data=valid_RT2(1:inx);
        test_data=valid_RT2(inx+1:end);
        subdata(d).train_data=train_data;
        subdata(d).test_data=test_data;
        record=fit_fun_bads(train_data,bins);
        subdata(d).record=record;
    end
    save(['cross_validation_IDDM/cross_validation_IDDM ', alldata(s).subdir_name],'subdata')
end


