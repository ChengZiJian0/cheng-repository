% 读取CE_INFO和SH_INFO两个表格，  为每一个被试数据整理其 去程起飞——去程落地——返程起飞——返程落地的时间
% 这里遗留一个问题， 需要确认清楚SH数据里的时间是否是北京时间， 因为SH数据的文件名时间和曹老师发的EXCEL表格里的时间差了8个小时，不确定以哪一个为准
% 认为原始数据的文件名中的时间信息为北京时间，也就是认为曹老师的excel结果可能是错误的

clear;clc;
load('process_data/step5_alldata.mat');
[~,~,CEXLS]=xlsread('scripts/CE_INFO.xlsx');
[~,~,SHXLS]=xlsread('scripts/SH_INFO.xlsx');

step6_alldata=step5_alldata;
%% 整理CE数据

% 表格的第13列表示去程日期， 第15列表示去程起飞时间，
% 第17列表示去程落地时间，如果这个时间为字符串，且显示**+1，则意味着超过了一天，那么落地的日期则为起飞日期+1
% 第18列表示返程日期，第20列表示返程起飞时间，第22列表示返程落地时间，其也可能出现为字符串***+1的形式

for sub=1:87
    
    thissub=CEXLS(sub+1,:);
    inx=strcmp({step6_alldata.subdir_name},thissub{1});
    inx=find(inx);
    if length(inx)~=1
        error('没找到或者找到了多个')
    end
    
    step6_alldata(inx).subinfo.gender=thissub{4}; %gender
    step6_alldata(inx).subinfo.brith=thissub{5};
    step6_alldata(inx).subinfo.age=thissub{6}; %age
    step6_alldata(inx).subinfo.driving_years=thissub{7}; %driving years
    
    %读取去程日期
    thedate1=num2str(thissub{13}); 
    thedate2=num2str(thissub{18}); %读取返程日期

    temp=datevec(thissub{15});
    timestr=['2021.',thedate1,'-',num2str(temp(4)),'-',num2str(temp(5))];
    t1_start=datetime(timestr,'Format','y.MM.d-HH-mm');
    t1_start=datetime(t1_start,'Format','y-MM-d HH:mm');
    
    if isstr(thissub{17}) %如果是字符串（也就是记录格式为 4:51+1 ）， 则说明到达后已经过了一天
        temp=thissub{17};
        temp(end-1:end)=[];
        timestr=['2021.',thedate1,'-', temp ];
        t1_end=datetime(timestr,'Format','y.MM.d-HH:mm')+days(1);
        t1_end=datetime(t1_end,'Format','y-MM-d HH:mm');
    else
        temp=datevec(thissub{17});
        timestr=['2021.',thedate1,'-',num2str(temp(4)),'-',num2str(temp(5))];
        t1_end=datetime(timestr,'Format','y.MM.d-HH-mm');
        t1_end=datetime(t1_end,'Format','y-MM-d HH:mm');
    end
    
    temp=datevec(thissub{20});
    timestr=['2021.',thedate2,'-',num2str(temp(4)),'-',num2str(temp(5))];
    t2_start=datetime(timestr,'Format','y.MM.d-HH-mm');
    t2_start=datetime(t2_start,'Format','y-MM-d HH:mm');
    
    if isstr(thissub{22}) %如果是字符串（也就是记录格式为 4:51+1 ）， 则说明到达后已经过了一天
        temp=thissub{22};
        temp(end-1:end)=[];
        timestr=['2021.',thedate2,'-', temp ];
        t2_end=datetime(timestr,'Format','y.MM.d-HH:mm')+days(1);
        t2_end=datetime(t2_end,'Format','y-MM-d HH:mm');
    else
        temp=datevec(thissub{22});
        timestr=['2021.',thedate2,'-',num2str(temp(4)),'-',num2str(temp(5))];
        t2_end=datetime(timestr,'Format','y.MM.d-HH-mm');
        t2_end=datetime(t2_end,'Format','y-MM-d HH:mm');
    end
    
    step6_alldata(inx).t1_start=datestr(t1_start,31);
    step6_alldata(inx).t1_end=datestr(t1_end,31);
    step6_alldata(inx).t2_start=datestr(t2_start,31);
    step6_alldata(inx).t2_end=datestr(t2_end,31);
    step6_alldata(inx).gap_dur=hours(t2_start-t1_end);
    step6_alldata(inx).t1_dur=hours(t1_end-t1_start);
    step6_alldata(inx).t2_dur=hours(t2_end-t2_start);
    
end

%% 整理SH数据
% 这些数据的阅读方式和CE相似， 但落地时间没有字符串，也没有+1这样的提示， 所以不能判断落地是不是第二天
% 但是航班时间不会超过24小时，因此落地时间如果小于起飞时间，则说明是第二天了
for sub=88:131
    thissub=SHXLS(sub-86,:);
    inx=strcmp({step6_alldata.subdir_name},thissub{2});
    inx=find(inx);
    if length(inx)~=1
        error('没找到或者找到了多个')
    end
    
    step6_alldata(inx).subinfo.gender=thissub{5}; %gender
    step6_alldata(inx).subinfo.brith=thissub{6};
    step6_alldata(inx).subinfo.age=thissub{7}; %age
    step6_alldata(inx).subinfo.driving_years=thissub{8}; %driving years
    
    try
        temp=datevec(thissub{16});
        timestr=[thissub{14},'/',num2str(temp(4)),'/',num2str(temp(5))];
        t1_start=datetime(timestr,'Format','y/MM/d/HH/mm');
        t1_start=datetime(t1_start,'Format','y-MM-d HH:mm');
        if thissub{18}>thissub{16} %如果落地时刻大于起飞时刻，则说明没有过一天
            temp=datevec(thissub{18});
            timestr=[thissub{14},'/',num2str(temp(4)),'/',num2str(temp(5))];
            t1_end=datetime(timestr,'Format','y/MM/d/HH/mm');
            t1_end=datetime(t1_end,'Format','y-MM-d HH:mm');
        else
            temp=datevec(thissub{18});
            timestr=[thissub{14},'/',num2str(temp(4)),'/',num2str(temp(5))];
            t1_end=datetime(timestr,'Format','y/MM/d/HH/mm')+days(1);
            t1_end=datetime(t1_end,'Format','y-MM-d HH:mm');
        end
        
        temp=datevec(thissub{21});
        timestr=[thissub{19},'/',num2str(temp(4)),'/',num2str(temp(5))];
        t2_start=datetime(timestr,'Format','y/MM/d/HH/mm');
        t2_start=datetime(t2_start,'Format','y-MM-d HH:mm');
        if thissub{23}>thissub{21} %如果落地时刻大于起飞时刻，则说明没有过一天
            temp=datevec(thissub{23});
            timestr=[thissub{19},'/',num2str(temp(4)),'/',num2str(temp(5))];
            t2_end=datetime(timestr,'Format','y/MM/d/HH/mm');
            t2_end=datetime(t2_end,'Format','y-MM-d HH:mm');
        else
            temp=datevec(thissub{23});
            timestr=[thissub{19},'/',num2str(temp(4)),'/',num2str(temp(5))];
            t2_end=datetime(timestr,'Format','y/MM/d/HH/mm')+days(1);
            t2_end=datetime(t2_end,'Format','y-MM-d HH:mm');
        end
        
        step6_alldata(inx).t1_start=datestr(t1_start,31);
        step6_alldata(inx).t1_end=datestr(t1_end,31);
        step6_alldata(inx).t2_start=datestr(t2_start,31);
        step6_alldata(inx).t2_end=datestr(t2_end,31);
        step6_alldata(inx).gap_dur=hours(t2_start-t1_end);
        step6_alldata(inx).t1_dur=hours(t1_end-t1_start);
        step6_alldata(inx).t2_dur=hours(t2_end-t2_start);
    catch
    end
    
end

%%
save('process_data/step6_alldata','step6_alldata');





