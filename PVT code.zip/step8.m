这个脚本不需要运行了，因为所绘制的结果没有意义，也观察不到任何趋势或者关系
% 对所有被试的5种状态计算均值，绘制散点图
% 修改第13行的1:87可以决定要绘制哪些被试的结果， 1:87表示东航， 88:131表示上航
% 修改18行的 gap_dur>10可以决定是否要剔除间隙过大的被试，  因为间隙过大意味着被试会有充分休息
% 这个脚本在绘制的时候，对于每一个被试，都会对其的一个阶段的所有结果进行平均(除非这个被试在某个阶段里只有一组fit结果)
% 因此图里的每一个阶段里的圆圈都表示一个被试的平均结果
% 每次运行脚本都需要指定绘制哪一个航班的信息，并且要制定保存结果的图片名称以及title

clear;clc;addpath('scripts');
load('process_data/step7_alldata');

Asuptitle='上航';
figname='SH_maxgap_5state.png';
subrange=88:131;

%%
all_state=cell(1,5); %每一个cell里都是一个阶段
for sub=subrange
    subdata=alldata(sub).subdata;
    if isempty(subdata)
        continue
    end
    if alldata(sub).gap_dur<10
        continue
    end
    
    subdata(cellfun(@isempty,{subdata.valid_RT}))=[];
    
    %计算每个被试在不同阶段里的参数均值， 如果被试不存在某个阶段，则用nan表示
    for ft=1:5        
        thisft=subdata([subdata.finish_type]==ft);
        
        if isempty( thisft )
            all_state{ft}=[all_state{ft};[NaN,NaN,NaN,NaN]];
        else
            all_state{ft}=[all_state{ft};mean(cat(1,thisft.params),1)];
        end
    end
    
end

%%
close all
pname={'drift rate Mean','drift rate Std','non-decision time','ndt range'};
for pa=1:4 %
    subplot(2,2,pa);
    hold on
    
    A={all_state{1}(:,pa),all_state{2}(:,pa),all_state{3}(:,pa),all_state{4}(:,pa),all_state{5}(:,pa)};
    N={'去程起飞前','去程航班中','间隙','返程航班中','返程结束后'};
    
    color=[0.5 0.5 0.5];
    figure_name=pname{pa};
    
    M=cellfun(@nanmean,A);
    S=cellfun(@nanstd,A);
    sub_N=cellfun(@(A)(sum(~isnan(A))),A);
    
    bar_num=length(A);
    bar(1:bar_num,M)
    
    for i=1:bar_num
        scatter(i+randn(1,length(A{i}))*0.1, A{i} );
    end
    
    set(gca,'XTick',1:bar_num,'XTickLabel',N);
    errorbar([1:bar_num],M, S./sqrt(sub_N) ,'Linestyle','None','linewidth',2);
    
%     rotateticklabel(gca,'x',60);
    
    ylabel(figure_name);
    
%     title(figure_name)
end
suptitle(Asuptitle)

%%
set(gcf,'position',[0 0 1500 1000]);
saveas(gcf,figname)

