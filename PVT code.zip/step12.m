% 在获取了每个被试在所有时间点（每10分钟一个点）里的alertness和fatigue结果之后
% 整理这些被试在每一次PVT任务时的fitigue或alertness状态
% 这些信息将被整理如subdata字段内， 标记在每一次pvt任务之后
% 另外，在alertness字段和kss字段下（可能也有fatigue字段），
% 新增了3列信息保存了每一个睡眠点对应的真实时间，以及这个时间下的pvt拟合参数值，以及这个pvt任务的完成时刻
% 但注意这里有一个问题是，每个睡眠点有10分钟，如果10分钟内完成多次任务，则只会记录最后一次任务的信息
% 不过这部分结果只用于绘图， 不影响后续的拟合工作

% 另外发现很多被试的作息时间和任务完成时间存在冲突，  也就是说部分任务是在睡眠期间完成的，这种情况在大部分被试身上都出现了1到2次，
% 少部分被试出现的次数更多，  task_in_sleep字段下记录了被试有多少个任务是在睡眠期间完成的，
% 注意这些任务仅考虑整个睡眠时间序列内的任务。

clear;clc;
load('process_data/step11_alldata');
step12_alldata=step11_alldata;
%% 首先将alertness信息整理到被试每次完成实验的信息中， 即subdata字段内
% subdata字段内的alertness_info字段保存了wake_status,alertness_value两个值，
% 第一个值1表示清醒，0表示睡着
% 第二个值则是相应的alertness_value 或者kss value
% 在第三列和第四列上加入当前时刻下的pvt任务的params信息以及任务完成时刻


for sub=1:length(step12_alldata)
    if isempty(step12_alldata(sub).alertness)
        continue;
    end
    if isempty(step12_alldata(sub).r)
        continue;
    end
    
    %整理每一个时间点下的alertness  kss
    alertness=step12_alldata(sub).alertness;
    kss=step12_alldata(sub).kss;
    sleep_schdule=step12_alldata(sub).sleep_schdule;
    tstart=sleep_schdule(1).tstart;
    for i=1:length(alertness)
        alertness{i,3}=tstart+(i-1)*minutes(10);
        kss{i,3}=tstart+(i-1)*minutes(10);
    end
    
    subdata=step12_alldata(sub).subdata;
    
    c=0;
    for d=1:length(subdata)
        TRIAL_DATE_TIME=datetime(subdata(d).TRIAL_DATE_TIME,'format','MM-dd-yyyy HH:mm'); %完成实验的时间
        temp=minutes(cellfun(@(a) minus(a,TRIAL_DATE_TIME),alertness(:,3)));  %找到被试当前完成实验时的对应alertness， 但如果不存在这个alertness，则跳过
        temp=abs(temp);
        if min(temp)>20
            continue;
        else
            c=c+1;
            [~,inx]=min(temp);
            alertness{inx,4}=subdata(d).params;
            alertness{inx,5}=subdata(d).TRIAL_DATE_TIME;
            kss{inx,4}=subdata(d).params;
            kss{inx,5}=subdata(d).TRIAL_DATE_TIME;
            wake_status=alertness{inx,1};
            alertness_value=alertness{inx,2};
            kss_value=kss{inx,2};
            subdata(d).alertness_info=[wake_status,alertness_value,hours(TRIAL_DATE_TIME-tstart)];
            subdata(d).kss_info=[wake_status,kss_value,hours(TRIAL_DATE_TIME-tstart)];
        end
    end
    step12_alldata(sub).subdata=subdata;
    
    temp=cat(1,subdata.alertness_info);
    step12_alldata(sub).task_in_sleep=sum(temp(:,1)==0);
    step12_alldata(sub).alertness=alertness;
    step12_alldata(sub).kss=kss;
    
    fprintf('.');
end

save('process_data/step12_alldata','step12_alldata');



%% 对step12_alldata进行一波筛选，去除所有缺失睡眠数据无法拟合的被试， 去除pvt任务少于10次的被试
step12_alldata_forFIPS_fit=step12_alldata;

inx=[];
for s=1:131
    if isempty(step12_alldata_forFIPS_fit(s).r2) || isempty(step12_alldata_forFIPS_fit(s).alertness)
        inx=[inx,s];
    end
end
step12_alldata_forFIPS_fit(inx)=[];

for s=1:length(step12_alldata_forFIPS_fit)
    subdata=step12_alldata_forFIPS_fit(s).subdata;
    inx=[];
    for d=1:length(subdata)
        if isempty(subdata(d).valid_RT2) || isempty(subdata(d).alertness_info)
            inx=[inx,d];
        end
    end
    subdata(inx)=[];
    step12_alldata_forFIPS_fit(s).subdata=subdata;
end

inx=[];
for s=1:length(step12_alldata_forFIPS_fit)
    if length(step12_alldata_forFIPS_fit(s).subdata)<10
        inx=[inx,s];
    end
end
    
step12_alldata_forFIPS_fit(inx)=[];
save('process_data/step12_alldata_forFIPS_fit','step12_alldata_forFIPS_fit');


%%

return

%% 对每个被试进行绘图， 绘图内容包含alertness变化与各个参数的值， 使用z分数进行绘制
mkdir('FIPS_with_params');
close all
for sub=1:length(step12_alldata)
    
    if isempty(step12_alldata(sub).alertness)
        continue;
    end
    if isempty(step12_alldata(sub).r)
        continue;
    end
    
    alertness=step12_alldata(sub).alertness;
%     kss=step12_alldata(sub).kss;
    
    temp=minutes(cellfun(@(a) minus(a,alertness{1,3}),alertness(:,3))); 
    
    figure
    pname={'drift-rate mean','drift-rate sd','non-decision time','range'};
    for p=1:4
        subplot(2,2,p)
        hold on
        
        %绘制浅色bar表示清醒
        wake_status=[alertness{:,1}];
        b=bar(1:length(temp),wake_status*4);
        b.BarWidth=1;
        b.FaceColor=[0.8745 0.8745 0.8745];
        
        b=bar(1:length(temp),-wake_status*4);
        b.BarWidth=1;
        b.FaceColor=[0.8745 0.8745 0.8745];
        
        %绘制深色bar表示睡眠
        b=bar(1:length(temp),~wake_status*4);
        b.BarWidth=1;
        b.FaceColor=[0.7608 0.7608 0.7608];
        b=bar(1:length(temp),-~wake_status*4);
        b.BarWidth=1;
        b.FaceColor=[0.7608 0.7608 0.7608];
        
        %绘制alertness
        alertness_value=[alertness{:,2}];
        plot(1:length(temp),zscore(alertness_value));
        
        %绘制前期拟合参数结果
        inx=find(~cellfun(@isempty,alertness(:,4)));
        ap=cat(1,alertness{inx,4});
        scatter(inx,zscore(ap(:,p)),'d');
        
        temp1=1:60:length(alertness);
        temp2=0:10:length(temp)*10;
        temp2(end)=[];
        temp2=mat2cell(temp2,1,ones(1,length(temp2)));
        set(gca,'XTick',temp1,'XTickLabel', temp2);
        xlabel('时间 (h)');
        
        ylabel([pname{p},'(zscore)']);
        title(pname{p});
        
    end
    set(gcf,'position',[0 0 1200 800]);
    saveas(gcf,['FIPS_with_params\alertness - ', step12_alldata(sub).subdir_name,'.png']);
    close all 
end


%% 整理所有被试每一次任务下的4参数结果，以及对应的alertness结果，绘制横轴为alertness，纵轴为4参数值的散点图，并加上回归线
all_ap=[];
for sub=1:length(step12_alldata)
    if isempty(step12_alldata(sub).alertness)
        continue;
    end
    if isempty(step12_alldata(sub).r)
        continue;
    end
    
    alertness=step12_alldata(sub).alertness;
    
    inx=find(~cellfun(@isempty,alertness(:,4)));
    
    ap=cat(1,alertness{inx,4});
    ap=[ap,[alertness{inx,2}]'];
    
    all_ap=[all_ap;ap];
    
end

figure;
for p=1:4
    subplot(2,2,p);
    
    mycorrelation(all_ap(:,5)',all_ap(:,p)')
    
end

set(gcf,'position',[0 0 1900 1000]);
saveas(gcf,'correlation alertness-DDM.png');












