% 对基于FIPS结果的fit结果计算各种模型拟合度指标
% 首先计算一次likelihood，然后计算AIC或BIC，因为之前的拟合并没有使用likelihood，所以需要先根据拟合结果反向计算每个拟合结果的likelihood值

clear;clc;
tic
addpath('scripts');
load('process_data/step12_alldata_forFIPS_fit');

%首先指定要比较哪几次拟合的结果， 另外再从fit_result里自动读取根目录下的纯DDM拟合的结果
% FIPS_fit_code={'第十七次fit','第十八次fit','第十九次fit','第二十次fit'};
% FIPS_fit_code_name={'p8','p9','p12','p16'};

FIPS_fit_code={'第十七次fit','第十九次fit','第十八次fit','第二十次fit'};
FIPS_fit_code_name={'1','2','3','4'};

%%  整理所有的AIC  BIC结果

ddm_fit=[cat(1,step12_alldata_forFIPS_fit.ddm_AIC),cat(1,step12_alldata_forFIPS_fit.ddm_BIC),cat(1,step12_alldata_forFIPS_fit.n)];
perAICddm=ddm_fit(:,1)./ddm_fit(:,3);
perBICddm=ddm_fit(:,2)./ddm_fit(:,3);

for f=1:size(FIPS_fit_code,2)
    thispath=FIPS_fit_code{1,f};
    load(['fit_with_FIPS_result\',thispath,'\step14_alldata.mat']);
    [~,index] = sortrows({step14_alldata.subdir_name}.'); step14_alldata = step14_alldata(index); clear index
    
    aicbic=[cat(1,step14_alldata.FIPS_AIC),cat(1,step14_alldata.FIPS_BIC),cat(1,step14_alldata.n)];
    FIPS_fit_code{2,f}=aicbic;
    
    perAIC=aicbic(:,1)./aicbic(:,3);
    perBIC=aicbic(:,2)./aicbic(:,3);
    
    FIPS_fit_code{3,f}=perAIC-perAICddm;
    FIPS_fit_code{4,f}=perBIC-perBICddm;
    
    lme{f}=perBIC*-0.5;
end
lme{f+1}=perBICddm*-0.5;

% FIPS_fit_code  每一列都是一个模型的结果
% 第一行标记第几个模型
% 第二行为该模型的AIC BIC 样本量N的结果
% 第三行，该模型的per AIC 与 per AIC ddm 的差值
% 第四行，该模型的per BIC 与 per BIC ddm 的差值


%%
figure
FIPS_fit_code_name={'1','2','3','4'};
%%
subplot(1,2,1);
cla
hold on
set(gca,'FontWeight','bold','Fontsize',13.5);
set(gca,'linewidth',2);
set(gcf,'Color',[1,1,1])

for i=1:size(FIPS_fit_code,2)
    delta=FIPS_fit_code{3,i};
    delta(delta==max(delta))=[];
    c=length(delta);
    
    %     text(i, -0.65,[num2str(round(sum(delta<0)/c*100)),'%']);
    
    b=bar(i ,mean(delta) ,'FaceColor',[0.8,0.8,0.8]);
    b.EdgeColor=[0.8,0.8,0.8];
    
    scatter(randn(1,c)*0.08+i,  delta,'CData',[0.5,0.5,0.5],'Marker','.','SizeData',100);
    errorbar(i , mean(delta) ,  std(delta)./sqrt(length(delta)) ,'Linestyle','None','linewidth',2,'Color',[0.2,0.2,0.2]);
    
end

% ylim([-0.7,0.3]);

set(gca,'XTick',1:size(FIPS_fit_code,2),'XTicklabel',FIPS_fit_code_name);
ylabel('Delta AIC');


%%
subplot(1,2,2);
cla
hold on
set(gca,'FontWeight','bold','Fontsize',13.5);
set(gca,'linewidth',2);
set(gcf,'Color',[1,1,1])

for i=1:size(FIPS_fit_code,2)
    delta=FIPS_fit_code{4,i};
    delta(delta==max(delta))=[];
    c=length(delta);
    
    b=bar(i ,mean(delta) ,'FaceColor',[0.8,0.8,0.8]);
    b.EdgeColor=[0.8,0.8,0.8];
    
    scatter(randn(1,c)*0.08+i,  delta,'CData',[0.5,0.5,0.5],'Marker','.','SizeData',100);
    errorbar(i , mean(delta) ,  std(delta)./sqrt(length(delta)) ,'Linestyle','None','linewidth',2,'Color',[0.2,0.2,0.2]);
    
end
% ylim([-0.7,0.3]);
set(gca,'XTick',1:size(FIPS_fit_code,2),'XTicklabel',FIPS_fit_code_name);
ylabel('Delta BIC');


% saveas(gcf,'AIC-BIC','svg');


%%
x=cat(2,lme{:});
[alpha,exp_r,xp,pxp,bor] = spm_BMS (x);

%%
figure
%%
subplot(1,2,1);
cla
hold on
b=bar(1:5 ,pxp ,'FaceAlpha',0);
b.EdgeColor=[0 0 0];
set(gca,'XTick',1:size(FIPS_fit_code,2),'XTicklabel',FIPS_fit_code_name);
ylim([0.15 0.25]);
ylabel('protected exceedance probabilities');

subplot(1,2,2);
cla
hold on
b=bar(1:5 ,alpha ,'FaceAlpha',0);
b.EdgeColor=[0 0 0];
set(gca,'XTick',1:size(FIPS_fit_code,2),'XTicklabel',FIPS_fit_code_name);
ylabel('model probabilities');
% saveas(gcf,'BMS_pxp','svg');


%BIC结果，第3个model比IDDM好了9.9%：
mean(FIPS_fit_code{4,3}./perBICddm)

%AIC结果，第3个model比IDDM好了3.3%：
mean(FIPS_fit_code{3,3}./perAICddm)

%pxp结果里，第3个model比IDDM好了17.6%：
(pxp(3)-pxp(5))/pxp(5)

%交叉验证结果，mixture model比I-DDM好了




