function pl=hist_frame_1(data1,bins1)

[nno_init,xxo]=hist(data1,bins1);
width1=xxo(2)-xxo(1);
xxo=[xxo(1)-width1,xxo];
xxo=repmat(xxo,2,1);
xxo=reshape(xxo,1,[]);
nno=repmat(nno_init,2,1);
nno=reshape(nno,1,[]);
nno=[0,nno,0];

%%
pl=plot( xxo+width1/2 ,nno);
pl.LineWidth=2;


set(gca,'LineWidth',2,'FontWeight','bold');
set(gca,'Box','off');


% xlabel('response time')
% ylabel('frequency');

% set(gca,'XScale','log') 
% set(gca,'XTick',[0.2,0.5,1,2],'XTickLabel',{'0.2','0.5','1','2'})
