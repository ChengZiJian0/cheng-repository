function draw_violin(p1,X, color,dot_color,errorbar_color,scale1,scale2)

hold on
[f,yi]=ksdensity(p1);
b1=fill(  [f,-f(end:-1:1)]*scale1+ X ,  [yi,yi(end:-1:1)], [1,1,1] );
b1.FaceColor=  color;
b1.EdgeColor= color;
b1.LineWidth=1;
b1.FaceAlpha=1;

% outliBool=isoutlier(p1,'quartiles');
% outli=p1(outliBool);
% scatter(repmat(X,[length(outli),1]),outli,20,'filled',...
%     'CData',[1 1 1],'MarkerEdgeColor',[0 0 0]);
% nY=p1(~outliBool);
% plot([1,1].*X, [min(nY),max(nY)] ,'Color', [0 0 0],'LineWidth',4 );
% plot([1,1].*X, [min(nY),max(nY)] ,'Color', [1,1,1],'LineWidth',2);
% 
% qt25=quantile(p1,0.25);
% qt75=quantile(p1,0.75);
% plot([1,1].*X, [qt25,qt75] ,'Color', [0 0 0],'LineWidth',6);
% plot([1,1].*X, [qt25,qt75] ,'Color', [1,1,1],'LineWidth',4);
% 
% M=mean(p1);
% plot([-1,1].*0.2+X, [M,M] ,'Color', [0 0 0],'LineWidth',1);


xx=scatter((randn(1,length(p1)))*scale2+X,p1,'CData',dot_color);
xx.MarkerFaceColor=dot_color;
xx.Marker='o';
xx.SizeData=10;



errorbar(X , mean(p1),  std(p1)./sqrt(length(p1)) ,'Linestyle','None','linewidth',2,'Color',errorbar_color);
