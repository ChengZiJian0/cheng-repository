function  record=fit_fun_bads(RTs,bins)

%% 这部分的代码存在问题， 目前第一次拟合到第九次拟合均使用这个代码完成
% 现在将这部分代码注释掉，统一更新为下方的代码块中的代码
% RTs=sort(RTs);
% inx=linspace(0.0001,bins,length(RTs));
% inx=ceil(inx);
% 
% for i=1:bins
%     thisinx=find(inx==i);
%     bins_end(1,i)=RTs(thisinx(1));
%     bins_end(2,i)=RTs(thisinx(end));
% end
% data=bins_end;

%%  更新为如下代码
RTs=sort(RTs);
inx=find(diff(RTs)==0);
RTs(inx)=RTs(inx)-0.000001; %防止相同的反应时变成边界，导致bin划分不准

inx=linspace(0.0001,bins,length(RTs));
inx=ceil(inx);
bins_end=[];
for i=1:bins
    thisinx=find(inx==i);
    bins_end(i)=RTs(thisinx(end));
end

bins_end(end)=Inf;
bins_end=[0,bins_end];
bins_info=[bins_end(1:end-1);bins_end(2:end)];
data=bins_info;

% 提前将每一个bin里的观测值记录入data
for i=1:bins
    inx1=RTs>data(1,i);
    inx2=RTs<=data(2,i);
    O(i)=sum(inx1.*inx2);
end

data(3,:)=O;

%%

fitfun=@(params) chi_square_fit_x(data,params);
bounds=[0.5  0  0 0  ;
    20 10  1 2] ;
% 漂移率均值， 漂移率标准差， ndt最小值， ndt变化范围

record=[];
tic;
parfor i=1:5
    range=bounds(2,:)-bounds(1,:);
    params=rand(1,length(range)).*range+bounds(1,:);
    [x1,fval,exitflag] = bads(fitfun,params,bounds(1,:),bounds(2,:),bounds(1,:),bounds(2,:));
    record(i,:)=[params,x1,fval,exitflag];
end
toc;

record=sortrows(record,size(record,2)-1);


