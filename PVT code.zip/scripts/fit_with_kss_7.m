function all_chi_square=fit_with_kss_7(subdata,params)

bins=5;

all_chi_square=0;
for d=1:length(subdata)
    
    kss_value=subdata(d).kss_info(2);
    
    
    drift_rate_m=params(2) * (  params(1)^kss_value) ;
    drift_rate_sd=params(4)* (params(3)^kss_value) ;
    ndt=params(6)* (params(5)^kss_value) ;
    ndt_range=params(8)* (params(7)^kss_value) ;
    
   
    RTs=subdata(d).valid_RT2;
    
    RTs=sort(RTs);
    inx=linspace(0.0001,bins,length(RTs));
    inx=ceil(inx);
    
    for i=1:bins
        thisinx=find(inx==i);
        bins_end(1,i)=RTs(thisinx(1));
        bins_end(2,i)=RTs(thisinx(end));
    end
    data=bins_end;
    
    [chi_square,~]=chi_square_fit_x(data, [drift_rate_m,drift_rate_sd,ndt,ndt_range] ,1000);
        
    all_chi_square=all_chi_square+chi_square;
    
end