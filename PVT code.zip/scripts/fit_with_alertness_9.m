function all_chi_square=fit_with_alertness_9(subdata,params)

% 最早是第9次fit所使用
% 为9参数模型
% 第一个参数使用ABC， 之后的都是AB

bins=5;

all_chi_square=0;
for d=1:length(subdata)
    
    alertness_value=subdata(d).alertness_info(2);
    
    drift_rate_m = params(1)*  (alertness_value^params(2)) + params(3) ;
    drift_rate_sd=params(5)* (params(4)^alertness_value) ;
    ndt=params(7)* (params(6)^alertness_value) ;
    ndt_range=params(9)* (params(8)^alertness_value) ;
   
        %%
    
    RTs=subdata(d).valid_RT2;
    RTs=sort(RTs);
    inx=find(diff(RTs)==0);
    RTs(inx)=RTs(inx)-0.000001; %防止相同的反应时变成边界，导致bin划分不准
    
    inx=linspace(0.0001,bins,length(RTs));
    inx=ceil(inx);
    bins_end=[];
    for i=1:bins
        thisinx=find(inx==i);
        bins_end(i)=RTs(thisinx(end));
    end
    
    bins_end(end)=Inf;
    bins_end=[0,bins_end];
    bins_info=[bins_end(1:end-1);bins_end(2:end)];
    data=bins_info;
    
    % 提前将每一个bin里的观测值记录入data
    for i=1:bins
        inx1=RTs>data(1,i);
        inx2=RTs<=data(2,i);
        O(i)=sum(inx1.*inx2);
    end
    
    data(3,:)=O;
    
    %%
    
    [chi_square,~]=chi_square_fit_x(data, [drift_rate_m,drift_rate_sd,ndt,ndt_range] ,5000);
        
    all_chi_square=all_chi_square+chi_square;
    
end