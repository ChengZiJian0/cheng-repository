function [beta,stats,t,p]=my_regress(Y,X)

%与regress一样，但可以输出每一个beta的t检验结果

beta=X\Y ;  %beta

k=size(X,2)-1;
n=length(Y);

tss=(Y-mean(Y))'*(Y-mean(Y));
rss=Y'*Y-beta'*X'*Y;  %SSE

R2=(tss-rss)/tss; %R2 与regress的输出结果的stats里第1个值一致
F=((tss-rss)/(k))/(rss/(n-k-1)); %F statistic 与regress的输出结果的stats里第2个值一致
p_all=1-fcdf(F,k,n-k-1);  %方程的整体检验，与regress的输出结果的stats里第3个值一致
MSE=rss/(n-k-1);  %与regress的输出结果的stats里第4个值一致

stats=[R2,F,p_all,MSE];

C=diag(inv(X'*X));
sigma=sqrt(rss/(n-k-1));
t=zeros(k,1);
for i=1:k
    t(i)=beta(i+1)/(sqrt(C(i+1))*sigma);
    p(i)=2*(1-tcdf(abs(t(i)),n-k-1));
end



