function nll=gene_nll(params,sample_num,bin_width,allRT)


[~,Tall]=chi_square_fit_x([], params ,sample_num);
bins=round((max(Tall)-min(Tall))/bin_width);
[no,xo]=hist(Tall,bins);

nll=0;
for i=1:length(allRT)
    RT=allRT(i);
    inx=find((RT>xo-bin_width/2).*(RT<xo+bin_width/2));
    if isempty(inx)
        p=eps;
    else
        p=no(inx(1))/sample_num*0.999999+eps;
    end
    nll=nll-log(p);
end