function draw_bar_with_errorbar(A,N,color,figure_name)
%
%AΪÿһ��bar��ԭʼ����

M=cellfun(@mean,A);
S=cellfun(@std,A);

sub_N=cellfun(@length,A);


% close
% h1=figure;
% set(h1, 'Position', [100 100 800 700]); 

bar_num=length(A);

%%
h1=bar(1:bar_num,M);
set(gca,'XTick',1:bar_num,'XTickLabel',N);


%%
set(h1,'facecolor',color)  % ��һ��������ͼ��ɫ

for p=1:bar_num
    hold on
    plot(p, A{p} ,'.','Color',color/2,'MarkerSize',8);
end
% xlabel(figure_name);


hold on
errorbar([1:bar_num],M, S./sqrt(sub_N) ,'Linestyle','None','linewidth',2,'Color',double(uint8(color*255)*1.5)/255);

title(figure_name)



% axis([0,bar_num+1,400,1500]);


%%
% saveas(gca,[figure_name,'.png']);




