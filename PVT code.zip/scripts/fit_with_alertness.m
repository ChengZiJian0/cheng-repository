function all_chi_square=fit_with_alertness(subdata,params)

bins=5;

all_chi_square=0;
for d=1:length(subdata)
    
    alertness_value=subdata(d).alertness_info(2);
    
    
    drift_rate_m=alertness_value^params(1)+params(2);
    drift_rate_sd=alertness_value^params(3)+params(4);
    ndt=alertness_value^params(5)+params(6);
    ndt_range=alertness_value^params(7)+params(8);
    
    RTs=subdata(d).valid_RT2;
    
    RTs=sort(RTs);
    inx=linspace(0.0001,bins,length(RTs));
    inx=ceil(inx);
    
    for i=1:bins
        thisinx=find(inx==i);
        bins_end(1,i)=RTs(thisinx(1));
        bins_end(2,i)=RTs(thisinx(end));
    end
    data=bins_end;
    
    [chi_square,~]=chi_square_fit_x(data, [drift_rate_m,drift_rate_sd,ndt,ndt_range] ,1000);
        
    all_chi_square=all_chi_square+chi_square;
    
end