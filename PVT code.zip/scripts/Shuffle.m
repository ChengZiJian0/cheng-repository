function [Y,index] = Shuffle(X, bindDim)


if nargin<2
    bindDim = [];
end

num_dim = ndims(X);
siz_unbind = size(X);
siz_unbind(bindDim) = 1;

sort_dim = find(siz_unbind>1,1);
permute_ind = [sort_dim, bindDim, setdiff(1:num_dim, [bindDim, sort_dim])];
X = permute(X, permute_ind); 

siz = size(X);
bind_ind = 2:(length(bindDim)+1);
unbind_ind = (length(bindDim)+2):num_dim;
num_bind = prod(siz(bind_ind));
num_unbind = prod(siz(unbind_ind));

rsp_siz = [siz(1), num_bind, num_unbind];
X = reshape(X, rsp_siz);
[~,index] = sort(rand([siz(1),1, num_unbind]));

index = repmat(index,1,num_bind) ...
    + repmat(0:siz(1):siz(1)*(num_bind-1), [siz(1),1,num_unbind])...
    + repmat(reshape(0:siz(1)*num_bind:siz(1)*num_bind*(num_unbind-1),1,1,num_unbind), siz(1), num_bind);

Y = X(index);
Y = permute(reshape(Y,siz), permute_ind);
index = permute(reshape(index,siz), permute_ind);

 
