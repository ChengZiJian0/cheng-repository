%--------------------------------------------------------------------------
% CHECKLIST
%--------------------------------------------------------------------------
% - check OPTIONS.FunValues provided as argument
% - play around with OPTIONS.ImprovementQuantile
% - added retrain at first search step (is it necessary?)
% - removed added point at the end of poll stage (was it necessary?)
% - fix restarts and multibayes?
% - compute func running time and perhaps do more stuff if func is slow
% - understand if the warping is working correctly, test more