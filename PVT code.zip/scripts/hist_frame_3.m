function hist_frame_3(data1,bins1,color1,data2,bins2,color2,data3,bins3,color3)

[nno_init,xxo]=hist(data1,bins1);
width1=xxo(2)-xxo(1);
xxo=[xxo(1)-width1,xxo];
xxo=repmat(xxo,2,1);
xxo=reshape(xxo,1,[]);
nno=repmat(nno_init,2,1);
nno=reshape(nno,1,[]);
nno=[0,nno,0];

[nno2_init,xxo2]=hist(data2,bins2);
width2=xxo2(2)-xxo2(1);
xxo2=[xxo2(1)-width2,xxo2];
xxo2=repmat(xxo2,2,1);
xxo2=reshape(xxo2,1,[]);
nno2=repmat(nno2_init,2,1);
nno2=reshape(nno2,1,[]);
nno2=[0,nno2,0];

[nno3_init,xxo3]=hist(data3,bins3);
width3=xxo3(2)-xxo3(1);
xxo3=[xxo3(1)-width3,xxo3];
xxo3=repmat(xxo3,2,1);
xxo3=reshape(xxo3,1,[]);
nno3=repmat(nno3_init,2,1);
nno3=reshape(nno3,1,[]);
nno3=[0,nno3,0];

%%
x1=width1*sum(nno_init) /  (width2*sum(nno2_init));

x2=width1*sum(nno_init) /  (width3*sum(nno3_init));

%%
hold on
pl=plot( xxo+width1/2 ,nno);
pl.LineWidth=1;
pl.Color=color1; %[0 0.4470 0.7410];

pl=plot( xxo2+width2/2 ,nno2*x1);
pl.LineWidth=2;
pl.Color=color2; %[0.8500    0.3250    0.0980];

pl=plot( xxo3+width3/2 ,nno3*x2);
pl.LineWidth=2;
pl.Color=color3; %


% legend({'generate data','true data'});

set(gcf,'Color',[1,1,1]);
set(gca,'LineWidth',2,'FontWeight','bold');
set(gca,'Box','off');

set(gca,'YTickLabel',{});
% xlabel('response time')
% ylabel('frequency');

% set(gca,'XScale','log') 
% set(gca,'XTick',[0.2,0.5,1,2],'XTickLabel',{'0.2','0.5','1','2'})
