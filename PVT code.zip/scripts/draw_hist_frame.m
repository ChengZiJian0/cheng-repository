function draw_hist_frame(data,bins,needbar)


[nno,xxo]=hist(data,bins);

width=xxo(2)-xxo(1);
xxo=[xxo(1)-width,xxo];
xxo=repmat(xxo,2,1);
xxo=reshape(xxo,1,[]);

nno=repmat(nno,2,1);
nno=reshape(nno,1,[]);
nno=[0,nno,0];

if needbar
    hist(data,bins);
    hold on
end

plot( xxo+width/2 ,nno)