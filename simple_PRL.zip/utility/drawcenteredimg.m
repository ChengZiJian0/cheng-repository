function drawcenteredimg(w,x,y,playmul,rotate,array)


texid=Screen('MakeTexture',w,array);
[m,n,~]=size(array);

disprect=[x-n/2*playmul,y-m/2*playmul,x+n/2*playmul,y+m/2*playmul];

Screen('DrawTexture',w,texid,[],disprect,rotate);

Screen('Close',texid);