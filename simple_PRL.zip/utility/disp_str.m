function disp_str(w,str,x,y,key,color,textsize)
if nargin==6
    textsize=30;
elseif nargin==5
    textsize=30;
    color=0;
elseif nargin==4
    textsize=30;
    color=0;
    key=32;
end
    
str=double(str);
oldsize=Screen('TextSize',w,textsize);
drect=Screen('TextBounds',w,str);

sx=x-drect(3)/2;
sy=y-drect(4)/2;

while 1
    [~,~,kc]=KbCheck;
    if kc(key)==0
        break;
    end
end

while 1
    Screen('DrawText',w,str,sx,sy,color);
    Screen('Flip',w);
    [~,~,kc]=KbCheck;
    if kc(key)
        break;
    end
end
while 1
    [~,~,kc]=KbCheck;
    if kc(key)==0
        break;
    end
end

Screen('TextSize',w,oldsize);