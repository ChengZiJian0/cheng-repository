1，运行程序需要安装PTB3.0.14及以上版本

2，运行时需要将工作路径切换到程序所在文件夹

![image-20211027154308632](C:\Users\ranger\AppData\Roaming\Typora\typora-user-images\image-20211027154308632.png)

3，运行simplePRL即可进入实验， 运行后需要输入被试编号，编号由字母和数字组成

4，实验中途可按ESC退出

5，实验结果保存于record文件夹，结果以实验日期-实验名称-被试编号为名

6，simplePRL脚本中包含自定义参数，可调整试次数量，刺激呈现大小，刺激位置等信息